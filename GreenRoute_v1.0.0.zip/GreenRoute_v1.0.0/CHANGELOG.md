# Release history

## 1.0.0 — 2026-10-26

- Local functional release; MIT source, no proprietary SYNTHIA material.
- Practicality/simplicity-first ranking; per-step confidence index and basis.
- 32 independent reaction-family rules, 31 enabled; duplicate carbon scaffold rejection and multiplicity retention.
- Intermediate/material constraints, manual one-step, manual route connectivity, batch targets and project feedback.
- Limited forward graph checks, explicitly not a learned feasibility model.
- PubChem adapters, sourced annotations, database entry points and configurable JSON REST.
- Structure identifiers, 3D rotation/conformer export, empirical charges, QM evidence and ORCA input generation.
- Username/password accounts, scoped tokens, owner-isolated SQLite records and audit trail.
- Chinese/English interface with extensible locale files.
- Text-only skills， opt-in compatible chat, Ollama and Synthia/avatar JSON connectors.
- NMR/evidence interchange API, schemas, examples, backup CLI, deployment and validation documentation.

## 0.1.0 — 2026-09-07

Initial local prototype: 20 rules, basic search, demonstration inventory, EHS-oriented ranking and HTML/JSON output.
