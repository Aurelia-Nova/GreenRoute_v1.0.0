# Third-party notices

GreenRoute's original application code and independent reaction templates are
distributed under the MIT license. No SYNTHIA/Chematica source, expert rule
library, commercial database export or proprietary model weights are included.
All product and database names remain the property of their respective owners.

Runtime dependencies are installed separately. 

Inspect each installed distribution's license for exact version-specific terms
and transitive dependencies. Database content is not relicensed by this
software. Public accessibility does not imply permission to redistribute,
bulk-download, train models on, or commercially exploit a dataset.

Built-in database connections are either official public APIs or clearly marked
browser links. Reaxys/CAS SciFinder access, supplier SDS, SDBS, NIST and other
resources retain their own subscription, attribution and use requirements.
