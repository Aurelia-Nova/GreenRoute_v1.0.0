from __future__ import annotations
import streamlit as st
from greenroute.storage import Store
from greenroute.auth import Auth
from greenroute.i18n import languages
from greenroute.ui_common import t

st.set_page_config(page_title="GreenRoute 1.0 · Synthesis Workbench",page_icon="🧭",layout="wide")
st.markdown("""<style>
.stApp{background:#f3f6f4}.block-container{max-width:1500px;padding-top:1.5rem}
h1,h2,h3{color:#173d30}div[data-testid="stMetric"]{background:white;border:1px solid #d6e4dc;border-radius:10px;padding:12px}
div[data-testid="stVerticalBlockBorderWrapper"]{border-radius:14px}
section[data-testid="stSidebar"]{background:#e9f0ec}
</style>""",unsafe_allow_html=True)
language_map=languages()
if "language" not in st.session_state:
    st.session_state.language="zh"
with st.sidebar:
    st.title("GreenRoute")
    st.caption("v1.0.0 · Local-first · MIT")
    st.selectbox("Language / 语言",list(language_map),format_func=lambda code:language_map[code]["name"],key="language")

store=Store()
auth=Auth(store)
user=auth.validate(st.session_state.get("session_token"),kind="session")
if user is None:
    st.title(t("合成路线工作台","Synthesis planning workbench"))
    st.info(t("本地首版：账号、项目、数据库和 skills 分用户隔离。首次使用请创建管理员。","Local release: accounts isolate projects, connections and skills. Create the administrator on first use."))
    bootstrap=not auth.has_users()
    with st.form("auth_form"):
        st.subheader(t("首次创建管理员" if bootstrap else "登录","Create first administrator" if bootstrap else "Sign in"))
        username=st.text_input(t("用户名","Username"),max_chars=40)
        password=st.text_input(t("密码（至少12字符）","Password (at least 12 characters)"),type="password",max_chars=128)
        confirm=st.text_input(t("确认密码","Confirm password"),type="password",max_chars=128) if bootstrap else password
        submitted=st.form_submit_button(t("创建管理员" if bootstrap else "登录","Create administrator" if bootstrap else "Sign in"),type="primary")
    if submitted:
        try:
            if bootstrap:
                if confirm!=password:
                    raise ValueError(t("两次密码不一致","Passwords do not match"))
                auth.create_user(username,password,bootstrap=True)
            st.session_state.session_token=auth.login(username,password)
            st.rerun()
        except (ValueError,PermissionError) as exc:
            st.error(str(exc))
        except Exception:
            st.error(t("账号创建或登录失败，请检查用户名是否已存在。","Account creation or login failed; the username may already exist."))
    st.caption(t("仅监听本机；不要直接暴露到公网。没有默认账号或默认密码。","Loopback only. Do not expose directly to the Internet. No default account or password."))
    st.stop()

if st.session_state.get("active_user")!=user["id"]:
    # Strong session separation, including when a different account signs in.
    for key in list(st.session_state):
        if key not in {"session_token","language"}:
            del st.session_state[key]
    st.session_state.active_user=user["id"]

from greenroute import ui_pages

PAGES=[
 ("plan","路线规划","Route planning",ui_pages.planning),
 ("compounds","化合物资料","Compound explorer",ui_pages.compound_page),
 ("chat","对话与 skills","Dialogue & skills",ui_pages.chat_page),
 ("projects","项目与反馈","Projects & feedback",ui_pages.projects_page),
 ("databases","数据库连接","Database connections",ui_pages.database_page),
 ("integrations","软件互联","Software integration",ui_pages.integration_page),
 ("inventory","库存","Inventory",ui_pages.inventory_page),
 ("rules","规则审计","Rule audit",ui_pages.rule_page),
 ("account","账户与安全","Account & security",ui_pages.account_page),
]
page_labels={p[0]:t(p[1],p[2]) for p in PAGES}
with st.sidebar:
    st.write(t("当前账户","Account")+": "+user["username"])
    selected=st.radio(t("工作区","Workspace"),[p[0] for p in PAGES],format_func=lambda k:page_labels[k],key="page")
    if st.button(t("退出登录","Sign out"),width="stretch"):
        auth.logout(st.session_state.session_token)
        for key in list(st.session_state):
            if key!="language":
                del st.session_state[key]
        st.rerun()
    st.caption(t("可信度为未校准指数；参考图谱与预测图谱分开标识。","Confidence is an uncalibrated index. Reference and predicted spectra are labeled separately."))
for key,zh,en,callback in PAGES:
    if key==selected:
        try:
            callback(store,user)
        except (ValueError,PermissionError) as exc:
            st.error(str(exc))
        break
