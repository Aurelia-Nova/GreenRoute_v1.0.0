"""Offline administrative operations. No network access or installed-code execution."""
import argparse
import getpass
import sqlite3
from pathlib import Path
from greenroute.storage import Store
from greenroute.auth import Auth

def main():
    parser=argparse.ArgumentParser()
    sub=parser.add_subparsers(dest="command",required=True)
    bootstrap=sub.add_parser("bootstrap-admin")
    bootstrap.add_argument("username")
    backup=sub.add_parser("backup")
    backup.add_argument("destination",help="New backup filename; refuses to overwrite")
    args=parser.parse_args()
    store=Store()
    if args.command=="bootstrap-admin":
        first=getpass.getpass("New password (12+ characters): ")
        second=getpass.getpass("Confirm: ")
        if first!=second:
            raise SystemExit("Passwords do not match")
        Auth(store).create_user(args.username,first,bootstrap=True)
        print("Administrator initialized")
    else:
        target=Path(args.destination).resolve()
        if target.exists():
            raise SystemExit("Destination exists; choose a new backup filename")
        target.parent.mkdir(parents=True,exist_ok=True)
        # Exclusive creation prevents accidental overwrite.
        with target.open("xb"):
            pass
        target.chmod(0o600)
        with sqlite3.connect(store.path) as source, sqlite3.connect(target) as destination:
            source.backup(destination)
        print("Backup complete. Contains account hashes, tokens and research: protect this file.")

if __name__=="__main__":
    main()

