# 软件、数据库和AI接入

## 数据库连接

数据库页面可以添加两类连接。web_link是网站入口，可在网址中用{query}表示经过URL编码的检索词；点击后由用户在浏览器内访问。json_rest是GET数据接口，同样使用{query}，要求服务返回JSON。返回内容只作为外部记录显示，不执行其中代码，不自动修改路线可信度。


## 接入本地或内网服务

默认禁止访问私有地址和HTTP远程服务。服务器管理员可以在启动进程前设置：

```powershell
# 仅在管理员信任本机AI/自建数据库服务后启用
$env:GREENROUTE_ALLOW_LOCAL_ENDPOINTS="1"
# 如需访问内网域名，显式列出受信任的主机，不包含协议、路径或端口
$env:GREENROUTE_TRUSTED_HOSTS="chemdb.internal,ai.internal"
.\start_windows.bat
```

允许本地接口只放行显式设置allow_local的请求；内网主机必须在受信任列表。公网接口要求HTTPS、有效证书、无URL内嵌账号密码。HTTP重定向不自动跟随，请直接填写最终接口地址。连接时固定到检查过的解析IP，减少DNS重绑定和元数据服务探测风险。

为避免其它账户借用服务器密钥，API变量必须以本账户前缀命名。前缀显示在AI设置页，例如GREENROUTE_KEY_<12位账户标识>_MAIN。实际密钥仅放启动进程环境，不写进项目、ZIP、日志或Git。先在同一终端设置变量，再启动软件；仅修改另一终端的环境不会影响正在运行的进程。

## AI与数字生命（开发中）

界面接受完整POST地址，不会自动补写路径。

数字生命适配器的输入协议见schemas/avatar-request.schema.json。GreenRoute将所选skill作为文本上下文传递，不传用户密码或API密钥。配置Bearer令牌时，令牌通过Authorization头发送给已配置的服务，不出现在URL或消息正文。


## 核磁分析等软件

令核磁软件和本软件各自保持独立，依靠协议交换候选结构与证据。GreenRoute不重新解析Bruker fid，不将现有核磁软件源码复制进来。核磁软件负责数据处理、峰识别和结构匹配，GreenRoute负责候选路线与化合物关联。

调用顺序：

1. 在GreenRoute“软件互联”创建read和evidence权限令牌。
2. 运行start_api_windows.bat，访问本机8502端口。
3. 核磁软件通过GET /api/v1/nmr/request?smiles=...获取结构核验请求，或读取界面导出的请求JSON。
4. 核磁软件返回greenroute.evidence.v1，明确compound_smiles、source、kind、origin、溶剂、核种、频率与峰信息。
5. 通过POST /api/v1/evidence写入，或由界面导入。协议、结构与数值通过校验后仍存为未审核证据。

已提供examples/nmr_bridge_client.py。它读取GREENROUTE_TOKEN环境变量并发送指定证据文件，不读取用户密码，不打印令牌。核磁软件只需生成兼容JSON并调用这个客户端，或直接调用HTTP接口。

origin必须区分experimental_reference、experimental_sample、predicted、unknown。预测数据不得标成标准实测图谱。导入时verified标记强制改为false，防止外部系统未经审核提升可信度。实际软件接口、数据单位、同分异构体身份、盐型和峰表格式仍需双方联调。

## 本地REST API

业务接口均要求Authorization: Bearer <token>。令牌绑定当前账户，不能指定另一个owner取得资料。
