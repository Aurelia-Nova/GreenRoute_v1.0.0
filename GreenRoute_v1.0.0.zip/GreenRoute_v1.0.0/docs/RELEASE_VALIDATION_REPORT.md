# GreenRoute 1.0.0 发布验证记录

日期：2026-10-26。发布类型：本地源码功能版。许可证：MIT。未向外部Git仓库或公网服务器发布。

涉密，略。

测试运行环境为Linux / Python 3.12.13。核心版本：RDKit 2026.3.6、Streamlit 1.63.0、FastAPI 0.162.0、Starlette 1.10.0、Uvicorn 0.54.0、urllib3 2.8.0、Plotly 6.9.0、pandas 2.2.3、pytest 8.4.2、HTTPX 0.28.1。
