"""Run against your GreenRoute API; reads a scoped token from the environment."""
import argparse
import json
import os
from urllib.request import Request,urlopen

parser=argparse.ArgumentParser()
parser.add_argument("evidence_json",help="Path to greenroute.evidence.v1 JSON exported by NMR software")
parser.add_argument("--endpoint",default="http://127.0.0.1:8502/api/v1/evidence")
args=parser.parse_args()
token=os.environ.get("GREENROUTE_TOKEN")
if not token:
    raise SystemExit("Set GREENROUTE_TOKEN to an evidence-scoped token")
with open(args.evidence_json,"r",encoding="utf-8-sig") as handle:
    evidence=json.load(handle)
request=Request(args.endpoint,data=json.dumps(evidence).encode(),method="POST",
                headers={"Content-Type":"application/json","Authorization":"Bearer "+token})
with urlopen(request,timeout=30) as response:
    print(response.read().decode())