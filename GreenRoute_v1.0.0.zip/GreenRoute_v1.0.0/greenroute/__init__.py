"""GreenRoute: local synthesis planning, compound research and AI skill workspace."""

__version__ = "1.0.0"
