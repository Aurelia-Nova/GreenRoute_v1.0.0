"""Opt-in authenticated interoperability API, bound to loopback by launchers."""
from __future__ import annotations
import threading
import time
from collections import defaultdict, deque
from typing import Literal
from fastapi import FastAPI, Header, HTTPException, Depends, Request
from pydantic import BaseModel, Field
from .storage import Store
from .auth import Auth, token_hash
from .service import make_plan, inventory_for, config_from_dict, VERSION
from .evidence import validate_evidence, nmr_request
from .compounds import local_profile, resolve_pubchem, pubchem_profile
from .skills_chat import reply

class LoginInput(BaseModel):
    username: str = Field(min_length=1,max_length=128)
    password: str = Field(min_length=1,max_length=128)

class PlanInput(BaseModel):
    target: str = Field(min_length=1,max_length=300000)
    config: dict = Field(default_factory=dict)
    include_demo_inventory: bool = True
    save: bool = False
    title: str = Field(default="API route",max_length=200)

class ChatInput(BaseModel):
    message: str = Field(min_length=1,max_length=12000)
    language: str = Field(default="zh",pattern=r"^[a-z][a-z0-9-]{1,9}$")
    project_id: str | None = None
    skill_id: str | None = None
    consent: bool = False

def create_app(store=None):
    store = store or Store()
    auth = Auth(store)
    app = FastAPI(title="GreenRoute interoperability API",version=VERSION)
    budget = defaultdict(deque)
    budget_lock = threading.Lock()
    planner_lock = threading.Lock()

    @app.middleware("http")
    async def security_headers(request: Request, call_next):
        length = request.headers.get("content-length")
        if length and not length.isdigit():
            from starlette.responses import JSONResponse
            return JSONResponse({"detail":"Invalid content length"},status_code=400)
        if (length and int(length) > 14_000_000) or request.headers.get("transfer-encoding"):
            from starlette.responses import JSONResponse
            return JSONResponse({"detail":"Request too large or chunked request refused"},status_code=413)
        total = bytearray()
        async for chunk in request.stream():
            total.extend(chunk)
            if len(total) > 14_000_000:
                from starlette.responses import JSONResponse
                return JSONResponse({"detail":"Request too large"},status_code=413)
        request._body = bytes(total)
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Cache-Control"] = "no-store"
        response.headers["Content-Security-Policy"] = "frame-ancestors 'none'"
        return response

    def actor(authorization: str | None = Header(default=None)):
        token = authorization[7:] if authorization and authorization.startswith("Bearer ") else ""
        user = auth.validate(token,kind="api")
        if not user:
            raise HTTPException(401,"A valid scoped API token is required")
        with budget_lock:
            queue = budget[token_hash(token)]
            now = time.time()
            while queue and queue[0] < now - 60:
                queue.popleft()
            if len(queue) >= 60:
                raise HTTPException(429,"API rate limit: 60 requests per minute")
            queue.append(now)
        return user

    def require(user, scope):
        if scope not in user["scopes"].split(","):
            raise HTTPException(403,"Token scope does not permit this operation")

    @app.get("/health")
    def health():
        return {"status":"ok","version":VERSION}

    @app.post("/api/v1/auth/login")
    def login(body: LoginInput):
        try:
            session = auth.login(body.username,body.password)
            user = auth.validate(session,kind="session")
            auth.logout(session)
            token = auth.issue(user["id"],ttl=8*3600,label="API password login",
                               scopes=["read","plan","evidence","chat"])
            return {"access_token":token,"token_type":"bearer","expires_in":8*3600}
        except ValueError:
            raise HTTPException(401,"Login failed or temporarily locked")

    @app.get("/api/v1/capabilities")
    def capabilities(user=Depends(actor)):
        require(user,"read")
        return {"schema_version":"greenroute.capabilities.v1","version":VERSION,
                "request":"greenroute.analysis-request.v1","evidence":"greenroute.evidence.v1",
                "avatar":"greenroute.avatar-request.v1",
                "features":["retrosynthesis","compound_descriptors","pubchem_lookup","skills_chat","evidence_exchange"],
                "not_implemented":["direct_bruker_processing","automatic_database_subscription_access","validated_success_probability"]}

    @app.post("/api/v1/routes")
    def plan(body: PlanInput, user=Depends(actor)):
        require(user,"plan")
        if not planner_lock.acquire(blocking=False):
            raise HTTPException(429,"Planner busy; retry later")
        try:
            project = make_plan(body.target,config_from_dict(body.config),
                                inventory_for(store,user["id"],include_demo=body.include_demo_inventory))
            if body.save:
                project["project_id"] = store.put(user["id"],"project",body.title,project)
            return project
        except (ValueError,TypeError) as exc:
            raise HTTPException(422,str(exc))
        finally:
            planner_lock.release()

    @app.get("/api/v1/projects")
    def projects(user=Depends(actor)):
        require(user,"read")
        return [{"id":r["id"],"title":r["title"],"updated":r["updated"]} for r in store.list(user["id"],"project")]

    @app.get("/api/v1/projects/{project_id}")
    def project(project_id: str,user=Depends(actor)):
        require(user,"read")
        row = store.get(user["id"],"project",project_id)
        if not row:
            raise HTTPException(404,"Project not found")
        return row

    @app.get("/api/v1/compounds/local")
    def compound(smiles: str,user=Depends(actor)):
        require(user,"read")
        try:
            return local_profile(smiles)
        except ValueError as exc:
            raise HTTPException(422,str(exc))

    @app.get("/api/v1/compounds/pubchem")
    def compound_online(query: str,kind: Literal["name","smiles","cid","inchikey"]="name",
                        cid: int | None=None, consent: bool=False,user=Depends(actor)):
        require(user,"read")
        if not consent:
            raise HTTPException(422,"Set consent=true to send this identifier to PubChem")
        try:
            return pubchem_profile(cid) if cid else {"candidate_cids":resolve_pubchem(query,kind)}
        except ValueError as exc:
            raise HTTPException(422,str(exc))

    @app.post("/api/v1/evidence")
    def import_evidence(body: dict,user=Depends(actor)):
        require(user,"evidence")
        try:
            validated = validate_evidence(body)
            record_id = store.put(user["id"],"evidence",validated["kind"]+": "+validated["compound_smiles"],validated)
            return {"id":record_id,"status":"stored_unverified"}
        except ValueError as exc:
            raise HTTPException(422,str(exc))

    @app.get("/api/v1/evidence")
    def evidence(smiles: str | None=None,user=Depends(actor)):
        require(user,"read")
        rows = store.list(user["id"],"evidence")
        if smiles:
            from .chemistry import canonical_smiles
            try:
                key = canonical_smiles(smiles)
            except ValueError as exc:
                raise HTTPException(422,str(exc))
            rows = [r for r in rows if r["payload"].get("compound_smiles")==key]
        return rows

    @app.get("/api/v1/nmr/request")
    def export_nmr(smiles: str, route_id: str="",user=Depends(actor)):
        require(user,"read")
        try:
            return nmr_request(smiles,route_id)
        except ValueError as exc:
            raise HTTPException(422,str(exc))

    @app.get("/api/v1/skills")
    def skills(user=Depends(actor)):
        require(user,"read")
        return [{"id":r["id"],"title":r["title"],"execution":"text_only_no_tools"} for r in store.list(user["id"],"skill")]

    @app.post("/api/v1/chat")
    def chat(body: ChatInput,user=Depends(actor)):
        require(user,"chat")
        context, skill = {}, None
        if body.project_id:
            row = store.get(user["id"],"project",body.project_id)
            if not row:
                raise HTTPException(404,"Project not found")
            context = row["payload"]
        if body.skill_id:
            row = store.get(user["id"],"skill",body.skill_id)
            if not row:
                raise HTTPException(404,"Skill not found")
            skill = row["payload"]
        settings = store.get(user["id"],"settings","ai")
        config = settings["payload"] if settings else {"mode":"offline"}
        try:
            text = reply(body.message,body.language,context,config=config,skill=skill,
                         consent=body.consent,user_id=user["id"])
            return {"reply":text,"language":body.language,"skill_id":body.skill_id}
        except PermissionError as exc:
            raise HTTPException(403,str(exc))
        except ValueError as exc:
            raise HTTPException(422,str(exc))
    return app
    
