"""Password accounts, rate limits, expiring sessions and scoped integration tokens."""
from __future__ import annotations
import hashlib
import hmac
import os
import re
import secrets
import time
import uuid
from .storage import Store

ITERATIONS = 600_000
PASSWORD_MIN = 12

def hash_password(password):
    if not PASSWORD_MIN <= len(password) <= 128:
        raise ValueError("Password must contain 12–128 characters / 密码须为12–128字符")
    salt = secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), ITERATIONS).hex()
    return f"pbkdf2_sha256${ITERATIONS}${salt}${digest}"

def verify_password(password, stored):
    try:
        name, iterations, salt, expected = stored.split("$")
        if name != "pbkdf2_sha256" or not 100_000 <= int(iterations) <= 2_000_000 or len(password) > 128:
            return False
        actual = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), int(iterations)).hex()
        return hmac.compare_digest(actual, expected)
    except (ValueError, TypeError):
        return False

def token_hash(token):
    return hashlib.sha256(token.encode()).hexdigest()

class Auth:
    def __init__(self, store: Store):
        self.store = store

    def has_users(self):
        with self.store.db() as db:
            return db.execute("SELECT 1 FROM users LIMIT 1").fetchone() is not None

    def create_user(self, username, password, *, actor=None, bootstrap=False):
        username = username.strip().casefold()
        if not re.fullmatch(r"[a-z0-9][a-z0-9_.-]{2,39}", username):
            raise ValueError("Username: 3–40 ASCII letters, digits, _, . or -")
        password_hash = hash_password(password)
        user_id = uuid.uuid4().hex
        with self.store.db() as db:
            db.execute("BEGIN IMMEDIATE")
            exists = db.execute("SELECT 1 FROM users LIMIT 1").fetchone()
            if bootstrap:
                if exists:
                    raise ValueError("Administrator already initialized")
                role = "admin"
            else:
                if not actor:
                    raise PermissionError("Only an administrator can create accounts")
                admin = db.execute("SELECT role,active FROM users WHERE id=?", (actor,)).fetchone()
                if not admin or admin["role"] != "admin" or not admin["active"]:
                    raise PermissionError("Administrator required")
                role = "chemist"
            db.execute("INSERT INTO users(id,username,password,role,created) VALUES(?,?,?,?,?)",
                       (user_id, username, password_hash, role, time.time()))
        self.store.audit(user_id, "account_created", role)
        return user_id

    def login(self, username, password):
        username = username.strip().casefold()[:128]
        key = token_hash("login:" + username)
        now = time.time()
        with self.store.db() as db:
            db.execute("BEGIN IMMEDIATE")
            attempt = db.execute("SELECT count,until FROM attempts WHERE key=?", (key,)).fetchone()
            if attempt and attempt["count"] >= 5 and attempt["until"] > now:
                raise ValueError("Too many attempts; wait 15 minutes / 尝试过多，请15分钟后重试")
            row = db.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
            stored = row["password"] if row else f"pbkdf2_sha256${ITERATIONS}$" + "0" * 32 + "$" + "0" * 64
            ok = verify_password(password, stored) and bool(row and row["active"])
            if not ok:
                count = attempt["count"] + 1 if attempt and attempt["until"] > now else 1
                db.execute("INSERT OR REPLACE INTO attempts VALUES(?,?,?)", (key, count, now + 900))
            else:
                db.execute("DELETE FROM attempts WHERE key=?", (key,))
        if not ok:
            raise ValueError("Invalid username or password / 用户名或密码错误")
        self.store.audit(row["id"], "login")
        return self.issue(row["id"], kind="session", ttl=8 * 3600, scopes=["ui"])

    def issue(self, owner, *, kind="api", ttl=30*86400, scopes=None, label=""):
        token = "gr_" + secrets.token_urlsafe(32)
        scopes = scopes or ["read", "plan", "evidence"]
        if not set(scopes).issubset({"read", "plan", "evidence", "chat", "ui"}):
            raise ValueError("Unknown token scope")
        with self.store.db() as db:
            db.execute("INSERT INTO sessions VALUES(?,?,?,?,?,?)",
                       (token_hash(token), owner, time.time() + ttl, kind, ",".join(scopes), label[:80]))
        self.store.audit(owner, "token_issued", kind)
        return token

    def validate(self, token, scope=None, kind=None):
        if not token or len(token) > 200:
            return None
        with self.store.db() as db:
            row = db.execute("SELECT u.id,u.username,u.role,u.active,s.expires,s.scopes,s.kind "
                             "FROM sessions s JOIN users u ON s.owner=u.id WHERE s.hash=?",
                             (token_hash(token),)).fetchone()
        if not row or not row["active"] or row["expires"] <= time.time():
            return None
        result = dict(row)
        if kind and result["kind"] != kind:
            return None
        if scope and scope not in result["scopes"].split(","):
            return None
        return result

    def logout(self, token):
        with self.store.db() as db:
            db.execute("DELETE FROM sessions WHERE hash=?", (token_hash(token),))

    def tokens(self, owner):
        with self.store.db() as db:
            return [dict(r) for r in db.execute("SELECT hash,expires,scopes,label FROM sessions WHERE owner=? AND kind='api'", (owner,))]

    def revoke(self, owner, hashed_token):
        with self.store.db() as db:
            db.execute("DELETE FROM sessions WHERE owner=? AND hash=?", (owner, hashed_token))
        self.store.audit(owner, "token_revoked")

    def change_password(self, owner, old_password, new_password):
        with self.store.db() as db:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute("SELECT password FROM users WHERE id=?", (owner,)).fetchone()
            if not row or not verify_password(old_password, row["password"]):
                raise ValueError("Current password is incorrect")
            db.execute("UPDATE users SET password=? WHERE id=?", (hash_password(new_password), owner))
            db.execute("DELETE FROM sessions WHERE owner=?", (owner,))
        self.store.audit(owner, "password_changed")