from __future__ import annotations

import html
from functools import lru_cache

from rdkit import Chem
from rdkit.Chem import Descriptors, Draw, rdMolDescriptors

from .models import StructuralAlert


def mol_from_smiles(smiles: str) -> Chem.Mol | None:
    if not isinstance(smiles, str) or not smiles.strip():
        return None
    try:
        mol = Chem.MolFromSmiles(smiles.strip())
        if mol is not None:
            Chem.SanitizeMol(mol)
        return mol
    except Exception:
        return None


def canonical_smiles(smiles_or_mol: str | Chem.Mol, isomeric: bool = True) -> str:
    mol = mol_from_smiles(smiles_or_mol) if isinstance(smiles_or_mol, str) else smiles_or_mol
    if mol is None:
        raise ValueError(f"Invalid SMILES: {smiles_or_mol!r}")
    return Chem.MolToSmiles(mol, canonical=True, isomericSmiles=isomeric)


@lru_cache(maxsize=4096)
def molecule_properties(smiles: str) -> dict[str, float | int | str]:
    mol = mol_from_smiles(smiles)
    if mol is None:
        raise ValueError(f"Invalid SMILES: {smiles!r}")
    chiral = Chem.FindMolChiralCenters(mol, includeUnassigned=True)
    return {
        "canonical_smiles": canonical_smiles(mol),
        "formula": rdMolDescriptors.CalcMolFormula(mol),
        "molecular_weight": round(Descriptors.MolWt(mol), 3),
        "heavy_atoms": mol.GetNumHeavyAtoms(),
        "rings": rdMolDescriptors.CalcNumRings(mol),
        "aromatic_rings": rdMolDescriptors.CalcNumAromaticRings(mol),
        "hetero_atoms": rdMolDescriptors.CalcNumHeteroatoms(mol),
        "rotatable_bonds": rdMolDescriptors.CalcNumRotatableBonds(mol),
        "stereocenters": len(chiral),
        "tpsa": round(rdMolDescriptors.CalcTPSA(mol), 2),
        "logp": round(Descriptors.MolLogP(mol), 2),
        "bertz_complexity": round(Descriptors.BertzCT(mol), 2),
    }


def synthetic_complexity(smiles: str) -> float:
    p = molecule_properties(smiles)
    return float(
        p["heavy_atoms"]
        + 2.2 * p["rings"]
        + 2.8 * p["stereocenters"]
        + 0.55 * p["hetero_atoms"]
        + 0.04 * p["bertz_complexity"]
    )


@lru_cache(maxsize=2048)
def molecule_png(smiles: str, width: int = 420, height: int = 260) -> bytes:
    mol = mol_from_smiles(smiles)
    if mol is None:
        return b""
    image = Draw.MolToImage(mol, size=(width, height), kekulize=True)
    from io import BytesIO

    stream = BytesIO()
    image.save(stream, format="PNG")
    return stream.getvalue()


@lru_cache(maxsize=2048)
def molecule_svg(smiles: str, width: int = 360, height: int = 220) -> str:
    mol = mol_from_smiles(smiles)
    if mol is None:
        return ""
    drawer = Draw.MolDraw2DSVG(width, height)
    Draw.PrepareAndDrawMolecule(drawer, mol)
    drawer.FinishDrawing()
    return drawer.GetDrawingText()


_ALERT_DEFS = (
    (
        "organic_azide",
        "有机叠氮结构警示",
        4,
        "潜在能量敏感性取决于分子量、碳/氮比与操作规模；必须单独评估。",
        "[$([N-]=[N+]=N),$([N]=[N+]=[N-])]",
    ),
    (
        "peroxide",
        "过氧键结构警示",
        5,
        "可能具有热、冲击或浓缩风险；不得仅凭结构评分确定操作条件。",
        "[O;X2]-[O;X2]",
    ),
    (
        "acyl_halide",
        "酰卤结构警示",
        3,
        "通常具有腐蚀性、遇水反应性或挥发暴露风险。",
        "[CX3](=[OX1])[F,Cl,Br,I]",
    ),
    (
        "isocyanate",
        "异氰酸酯结构警示",
        5,
        "存在显著吸入与致敏风险，应优先采用密闭转移与替代方案。",
        "N=C=O",
    ),
    (
        "nitrile",
        "腈基结构提示",
        2,
        "危害不能由腈基单独判定；需查阅具体物质 SDS 与代谢/分解信息。",
        "[CX2]#N",
    ),
    (
        "epoxide",
        "环氧化物结构警示",
        4,
        "部分低分子环氧化物具有挥发性、烷基化和致敏风险。",
        "[O;r3]1[C;r3][C;r3]1",
    ),
    (
        "organolithium",
        "有机锂/锂试剂提示",
        5,
        "通常涉及自燃、强碱性或遇水剧烈反应风险。",
        "[Li]",
    ),
    (
        "organomagnesium",
        "有机镁试剂提示",
        4,
        "通常要求严格控水控氧，并评估引发、失控放热及淬灭。",
        "[Mg]-[F,Cl,Br,I]",
    ),
    (
        "nitro",
        "硝基结构提示",
        2,
        "部分多硝基或低氧平衡化合物具有能量风险；单硝基命中不等于危险品结论。",
        "[N+](=O)[O-]",
    ),
    (
        "thiol",
        "硫醇结构提示",
        2,
        "可能具有显著气味、挥发暴露和氧化问题。",
        "[SH]",
    ),
    (
        "aldehyde",
        "醛结构提示",
        2,
        "部分低分子醛具有挥发、刺激或致敏风险。",
        "[CX3H1](=O)[#6]",
    ),
    (
        "michael_acceptor",
        "Michael 受体结构提示",
        3,
        "部分化合物可能具有亲电反应性和皮肤致敏风险。",
        "[C,c]=[C,c][C,S](=O)",
    ),
)


@lru_cache(maxsize=1)
def _compiled_alerts() -> tuple[tuple[str, str, int, str, Chem.Mol], ...]:
    compiled = []
    for code, label, severity, note, smarts in _ALERT_DEFS:
        query = Chem.MolFromSmarts(smarts)
        if query is not None:
            compiled.append((code, label, severity, note, query))
    return tuple(compiled)


@lru_cache(maxsize=4096)
def structural_alerts(smiles: str) -> tuple[StructuralAlert, ...]:
    mol = mol_from_smiles(smiles)
    if mol is None:
        return ()
    hits = []
    for code, label, severity, note, query in _compiled_alerts():
        if mol.HasSubstructMatch(query):
            hits.append(StructuralAlert(code, label, severity, note))
    halogens = sum(1 for atom in mol.GetAtoms() if atom.GetAtomicNum() in {9, 17, 35, 53})
    if halogens >= 4:
        hits.append(
            StructuralAlert(
                "polyhalogenated",
                "多卤代结构提示",
                3,
                "可能增加持久性、废物处理或燃烧副产物方面的环境负担。",
            )
        )
    return tuple(sorted(hits, key=lambda item: (-item.severity, item.code)))


def safe_formula_label(smiles: str) -> str:
    try:
        p = molecule_properties(smiles)
        return f"{p['formula']} · Mr {p['molecular_weight']}"
    except ValueError:
        return html.escape(smiles)
