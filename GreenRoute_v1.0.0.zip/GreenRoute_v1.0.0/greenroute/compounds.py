"""Public compound metadata retrieval with field-level provenance and local calculation."""
from __future__ import annotations
import json
import math
from datetime import datetime, timezone
from urllib.parse import quote, urlencode
from rdkit import Chem
from rdkit.Chem import AllChem, Descriptors, rdMolDescriptors
from .chemistry import canonical_smiles, mol_from_smiles, molecule_properties, structural_alerts
from .network import json_request, request

PUG = "https://pubchem.ncbi.nlm.nih.gov/rest/pug"
VIEW = "https://pubchem.ncbi.nlm.nih.gov/rest/pug_view/data/compound"

def now_iso():
    return datetime.now(timezone.utc).isoformat()

def parse_structure(text):
    raw_text = text
    text = text.strip()
    if len(text) > 300_000:
        raise ValueError("Structure input is too large")
    if text.startswith("InChI="):
        mol = Chem.MolFromInchi(text)
    elif "M  END" in text:
        # Supports the first record of a Molfile/SDF; multi-target import is a separate function.
        # Molfile's three header lines may be intentionally blank. Never strip them.
        mol = Chem.MolFromMolBlock(raw_text.split("$$$$")[0], sanitize=True)
    else:
        mol = mol_from_smiles(text)
    if mol is None:
        raise ValueError("Cannot parse structure / 无法解析结构")
    return canonical_smiles(mol)

def local_profile(smiles):
    smiles = parse_structure(smiles)
    mol = mol_from_smiles(smiles)
    data = molecule_properties(smiles).copy()
    data.update(exact_mass=round(Descriptors.ExactMolWt(mol), 6),
                hbd=rdMolDescriptors.CalcNumHBD(mol), hba=rdMolDescriptors.CalcNumHBA(mol),
                inchi=Chem.MolToInchi(mol), inchikey=Chem.MolToInchiKey(mol),
                stereo_centers=Chem.FindMolChiralCenters(mol, includeUnassigned=True),
                source="RDKit local descriptors; calculated, not experimental")
    return data

def resolve_pubchem(query, query_type="name"):
    if not query.strip() or len(query) > 3000:
        raise ValueError("Invalid query")
    if query_type not in {"name", "smiles", "cid", "inchikey"}:
        raise ValueError("Unsupported identifier type")
    url = f"{PUG}/compound/{query_type}/{quote(query.strip(), safe='')}/cids/JSON"
    payload = json_request(url)
    cids = payload.get("IdentifierList", {}).get("CID", [])
    if not cids:
        raise ValueError("No matching PubChem compound")
    # Ambiguous names can return multiple CIDs: surface candidates, never silently merge.
    return cids[:20]

def pubchem_profile(cid):
    cid = int(cid)
    if cid <= 0:
        raise ValueError("Invalid CID")
    props = "MolecularFormula,MolecularWeight,IsomericSMILES,InChI,InChIKey,IUPACName,XLogP,TPSA,HBondDonorCount,HBondAcceptorCount"
    url = f"{PUG}/compound/cid/{cid}/property/{props}/JSON"
    payload = json_request(url)
    record = payload.get("PropertyTable", {}).get("Properties", [{}])[0]
    return {"cid": cid, "properties": record, "source": url, "retrieved_at": now_iso(),
            "data_kind":"database properties; some fields are calculated",
            "compound_url": f"https://pubchem.ncbi.nlm.nih.gov/compound/{cid}"}

def _flatten_sections(sections, references, trail=()):
    rows = []
    for section in sections:
        heading = section.get("TOCHeading", "")
        path = trail + (heading,)
        for item in section.get("Information", []):
            value = item.get("Value", {})
            strings = value.get("StringWithMarkup", [])
            text_value = "; ".join(s.get("String", "") for s in strings)
            if not text_value and "Number" in value:
                text_value = ", ".join(map(str, value["Number"]))
            if value.get("Unit"):
                text_value += " " + value["Unit"]
            ref = references.get(item.get("ReferenceNumber"), {})
            urls = [m["URL"] for s in strings for m in s.get("Markup", []) if m.get("URL")]
            rows.append({"section": " / ".join(path), "name": item.get("Name", heading),
                         "value": text_value, "source_name": ref.get("SourceName", ""),
                         "source_url": item.get("URL") or ref.get("URL", ""),
                         "reference_number":item.get("ReferenceNumber"), "links":urls})
        rows.extend(_flatten_sections(section.get("Section", []), references, path))
    return rows

def pubchem_annotations(cid, heading):
    allowed = {"Chemical and Physical Properties", "Spectral Information", "Safety and Hazards"}
    if heading not in allowed:
        raise ValueError("Unsupported annotation heading")
    url = f"{VIEW}/{int(cid)}/JSON?{urlencode({'heading':heading})}"
    payload = json_request(url)
    record = payload.get("Record", {})
    refs = {r["ReferenceNumber"]:r for r in record.get("Reference", [])}
    return {"cid":int(cid), "heading":heading, "rows":_flatten_sections(record.get("Section", []), refs),
            "source":url, "retrieved_at":now_iso(),
            "notice":"Hazard annotations are not a supplier-specific current SDS; spectra can be measured or predicted—inspect source."}

def pubchem_sdf(cid):
    return request(f"{PUG}/compound/cid/{int(cid)}/SDF?record_type=3d", max_bytes=2_000_000).decode()

def generate_conformer(smiles):
    smiles = parse_structure(smiles)
    mol = Chem.AddHs(mol_from_smiles(smiles))
    if mol.GetNumAtoms() > 180:
        raise ValueError("Local conformer limited to 180 atoms including hydrogen")
    params = AllChem.ETKDGv3()
    params.randomSeed = 20261026
    if AllChem.EmbedMolecule(mol, params) < 0:
        raise ValueError("3D embedding failed; no conformer was generated")
    model, energy, status = "ETKDG geometry only", None, None
    if AllChem.MMFFHasAllMoleculeParams(mol):
        status = AllChem.MMFFOptimizeMolecule(mol, maxIters=400)
        ff = AllChem.MMFFGetMoleculeForceField(mol, AllChem.MMFFGetMoleculeProperties(mol))
        energy, model = ff.CalcEnergy(), "MMFF94"
    elif AllChem.UFFHasAllMoleculeParams(mol):
        status = AllChem.UFFOptimizeMolecule(mol, maxIters=400)
        energy, model = AllChem.UFFGetMoleculeForceField(mol).CalcEnergy(), "UFF"
    charges = []
    try:
        AllChem.ComputeGasteigerCharges(mol)
        for atom in mol.GetAtoms():
            q = float(atom.GetProp("_GasteigerCharge"))
            charges.append(q if math.isfinite(q) else None)
    except Exception:
        charges = []
    conf = mol.GetConformer()
    atoms = [{"element":a.GetSymbol(), "x":conf.GetAtomPosition(a.GetIdx()).x,
              "y":conf.GetAtomPosition(a.GetIdx()).y, "z":conf.GetAtomPosition(a.GetIdx()).z}
             for a in mol.GetAtoms()]
    return {"smiles":smiles, "model":model, "energy_kcal_mol":energy, "optimizer_status":status,
            "converged":status == 0, "atoms":atoms,
            "bonds":[[b.GetBeginAtomIdx(), b.GetEndAtomIdx()] for b in mol.GetBonds()],
            "gasteiger_charges":charges, "molblock":Chem.MolToMolBlock(mol),
            "xyz":Chem.MolToXYZBlock(mol),
            "notice":"One calculated conformer; not a crystal structure, global minimum, DFT energy, HOMO/LUMO or experimental spectrum."}

def orca_input(conformer, charge=0, multiplicity=1):
    mol = mol_from_smiles(conformer["smiles"])
    electrons = sum(a.GetAtomicNum() for a in Chem.AddHs(mol).GetAtoms()) - int(charge)
    if multiplicity < 1 or (electrons - multiplicity + 1) % 2:
        raise ValueError("Charge/multiplicity electron parity is inconsistent")
    lines = conformer["xyz"].splitlines()[2:]
    return "! PBE0 def2-SVP TightSCF Opt\n%pal nprocs 4 end\n%maxcore 1000\n" + f"* xyz {int(charge)} {int(multiplicity)}\n" + "\n".join(lines) + "\n*\n"
