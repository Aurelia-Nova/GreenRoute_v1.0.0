"""Explicit connection modes: web link, public API or user-configured JSON REST."""
from __future__ import annotations
import os
import re
from urllib.parse import quote, urlsplit
from .network import json_request

BUILTINS = [
 {"id":"pubchem","name":"PubChem","mode":"public_api","url":"https://pubchem.ncbi.nlm.nih.gov/#query={query}","scope":"properties / spectra annotations / hazards / 3D"},
 {"id":"nist","name":"NIST Chemistry WebBook","mode":"web_link","url":"https://webbook.nist.gov/cgi/cbook.cgi?Name={query}&Units=SI","scope":"IR / MS / UV / thermochemistry (coverage varies)"},
 {"id":"sdbs","name":"AIST SDBS","mode":"web_link","url":"https://sdbs.db.aist.go.jp/","scope":"reference NMR / IR / MS; manual search and license terms"},
 {"id":"massbank","name":"MassBank","mode":"web_link","url":"https://massbank.eu/MassBank/","scope":"mass spectra; manual search"},
 {"id":"reaxys","name":"Reaxys","mode":"licensed_web","url":"https://www.reaxys.com/","scope":"licensed reaction / property / spectrum database; not an implemented API"},
 {"id":"scifinder","name":"CAS SciFinder","mode":"licensed_web","url":"https://scifinder-n.cas.org/","scope":"licensed structure / reaction / literature database; not an implemented API"},
 {"id":"chemspider","name":"ChemSpider","mode":"web_link","url":"https://www.chemspider.com/","scope":"structure / physicochemical records"},
 {"id":"chembl","name":"ChEMBL","mode":"web_link","url":"https://www.ebi.ac.uk/chembl/","scope":"bioactivity / structure"},
 {"id":"sigma","name":"Merck / Sigma-Aldrich SDS","mode":"web_link","url":"https://www.sigmaaldrich.com/","scope":"supplier-specific SDS; choose site, product, concentration, revision"},
]

def validate_connection(data):
    name = str(data.get("name", "")).strip()
    mode = data.get("mode", "web_link")
    template = str(data.get("url", "")).strip()
    if not name or len(name) > 100 or mode not in {"web_link","json_rest"}:
        raise ValueError("Invalid connection name or mode")
    parsed = urlsplit(template.replace("{query}", "example"))
    if parsed.scheme not in {"http","https"} or not parsed.hostname or parsed.username or parsed.password:
        raise ValueError("Endpoint must be an HTTP(S) URL without credentials")
    if "{" in template.replace("{query}","") or "}" in template.replace("{query}",""):
        raise ValueError("Only {query} placeholder is supported")
    if mode == "json_rest" and "{query}" not in template:
        raise ValueError("JSON REST URL must contain {query}")
    env = str(data.get("api_key_env", "")).strip()
    if env and not re.fullmatch(r"GREENROUTE_KEY_[A-Z0-9_]{1,80}", env):
        raise ValueError("Use a GREENROUTE_KEY_... environment variable, never store a key here")
    return {"name":name,"mode":mode,"url":template,"api_key_env":env,
            "allow_local":bool(data.get("allow_local",False)), "scope":str(data.get("scope",""))[:300]}

def connection_url(connection, query):
    return connection["url"].replace("{query}", quote(query, safe=""))

def fetch_custom(connection, query, *, key_env_allowed=None):
    connection = validate_connection(connection)
    if connection["mode"] != "json_rest":
        raise ValueError("This connection is a browser link, not a data adapter")
    headers = {}
    env = connection.get("api_key_env")
    if env:
        if key_env_allowed is None or env not in key_env_allowed:
            raise PermissionError("Key environment variable not assigned to this account")
        key = os.environ.get(env)
        if not key:
            raise ValueError("Configured API key environment variable is not set")
        headers["Authorization"] = "Bearer " + key
    return json_request(connection_url(connection, query), headers=headers, allow_local=connection["allow_local"])

