"""Independent, budgeted AND/OR best-first search. No proprietary algorithms."""
from __future__ import annotations
import hashlib
import heapq
from dataclasses import dataclass, field
from .chemistry import canonical_smiles, molecule_properties, synthetic_complexity
from .inventory import Inventory
from .models import RouteResult, RouteStep, SearchConfig, SearchDiagnostics
from .rules import RuleLibrary
from .scoring import aggregate_route_scores, assess_step

@dataclass(order=True)
class _State:
    priority: float
    serial: int
    frontier: tuple[str, ...] = field(compare=False)
    steps: tuple[RouteStep, ...] = field(compare=False)
    decomposed: frozenset[str] = field(compare=False)

class RetrosynthesisEngine:
    def __init__(self, rule_library: RuleLibrary, inventory: Inventory):
        self.rule_library = rule_library
        self.inventory = inventory

    def _availability(self, smiles, config):
        return self.inventory.lookup(smiles, allow_simple_terminal=config.allow_simple_terminal,
                                     simple_terminal_heavy_atoms=config.simple_terminal_heavy_atoms)

    def _unresolved(self, frontier, config):
        return sorted((s for s in frontier if not self._availability(s, config).available),
                      key=lambda s: (-synthetic_complexity(s), s))

    def one_step(self, product: str, config: SearchConfig):
        product = canonical_smiles(product)
        excluded = {canonical_smiles(s) for s in config.excluded_smiles}
        for rule in self.rule_library.enabled_rules(config.enabled_categories):
            for precursors in self.rule_library.apply(rule, product):
                if any(s in excluded for s in precursors):
                    continue
                assessment = assess_step(rule, precursors, config, product)
                if not assessment.blocked_reasons:
                    yield RouteStep(product, precursors, rule.id, rule.name_zh, rule.category,
                                    rule.reagents, rule.solvents, rule.catalysts, rule.temperature,
                                    rule.exposure_controls_zh, rule.evidence_level, assessment)

    def _make_result(self, target, state, config):
        terminals = tuple(self._availability(s, config) for s in state.frontier)
        scores = aggregate_route_scores(state.steps, terminals, config)
        signature = target + repr([(s.product, s.precursors, s.rule_id) for s in state.steps])
        route_id = hashlib.sha256(signature.encode()).hexdigest()[:12].upper()
        notes = ["Confidence is an uncalibrated rule-based index, not yield or experimental success probability."]
        if any(t.source == "built_in" for t in terminals):
            notes.append("Availability uses a demonstration inventory; replace with verified inventory.")
        if any(t.basis == "simple_material_assumption" for t in terminals):
            notes.append("Small material availability is assumed, not catalog-verified.")
        complete = all(t.available for t in terminals)
        if not complete:
            notes.append("Partial route: some terminal materials remain unresolved.")
        return RouteResult(route_id, target, state.steps, terminals, complete,
                           scores["overall"], scores["safety"], scores["green"],
                           scores["practicality"], scores["confidence"], scores["availability"], tuple(notes))

    def search(self, target_smiles, config):
        target = canonical_smiles(target_smiles)
        if "." in target or molecule_properties(target)["heavy_atoms"] > 120:
            raise ValueError("Use one connected target with at most 120 heavy atoms.")
        required = {canonical_smiles(s) for s in config.required_intermediates}
        excluded = {canonical_smiles(s) for s in config.excluded_smiles}
        if target in excluded:
            raise ValueError("Target is excluded")
        diagnostics = SearchDiagnostics()
        queue = [_State(synthetic_complexity(target), 0, (target,), (), frozenset())]
        serial, candidates, seen = 1, [], set()
        rules = self.rule_library.enabled_rules(config.enabled_categories)
        while queue and diagnostics.expansions < config.max_expansions:
            state = heapq.heappop(queue)
            diagnostics.expansions += 1
            unresolved = self._unresolved(state.frontier, config)
            if not state.steps and config.force_synthesis:
                unresolved = [target]
            if not unresolved or len(state.steps) >= config.max_depth:
                if state.steps or not config.force_synthesis:
                    candidates.append(state)
                continue
            focus, children = unresolved[0], 0
            for rule in rules:
                diagnostics.rule_applications += 1
                for precursors in self.rule_library.apply(rule, focus):
                    if focus in precursors or any(s in state.decomposed or s in excluded for s in precursors):
                        continue
                    assessment = assess_step(rule, precursors, config, focus)
                    if assessment.blocked_reasons:
                        diagnostics.blocked_disconnections += 1
                        continue
                    frontier = list(state.frontier)
                    frontier.remove(focus)
                    frontier.extend(precursors)
                    frontier = tuple(sorted(frontier))
                    step = RouteStep(focus, precursors, rule.id, rule.name_zh, rule.category,
                                     rule.reagents, rule.solvents, rule.catalysts, rule.temperature,
                                     rule.exposure_controls_zh, rule.evidence_level, assessment)
                    steps = state.steps + (step,)
                    key = (frontier, tuple(sorted((s.product, s.rule_id, s.precursors) for s in steps)))
                    if key in seen:
                        continue
                    seen.add(key)
                    priority = len(steps) * (6 + config.step_penalty) + sum(synthetic_complexity(s) for s in self._unresolved(frontier, config))
                    priority += sum((100 - s.assessment.practicality_score) * .08 for s in steps)
                    heapq.heappush(queue, _State(priority, serial, frontier, steps, state.decomposed | {focus}))
                    serial += 1
                    diagnostics.valid_disconnections += 1
                    children += 1
            if not children and state.steps:
                candidates.append(state)
        diagnostics.exhausted = bool(queue)
        candidates.extend(heapq.nsmallest(config.max_routes * 4, queue))
        results, unique = [], set()
        for state in candidates:
            if not state.steps and config.force_synthesis:
                continue
            visited_materials = set(state.frontier) | {s.product for s in state.steps}
            if not required.issubset(visited_materials):
                continue
            result = self._make_result(target, state, config)
            if result.route_id not in unique:
                unique.add(result.route_id)
                results.append(result)
        results.sort(key=lambda r: (not r.complete, -r.overall_score, len(r.steps), r.route_id))
        return results[:config.max_routes], diagnostics

