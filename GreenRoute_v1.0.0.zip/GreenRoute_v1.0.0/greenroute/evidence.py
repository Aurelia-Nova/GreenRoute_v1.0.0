"""Interchange bridge for NMR, SDS, quantum calculations and internal reaction evidence."""
from __future__ import annotations
import math
from .chemistry import canonical_smiles

KINDS = {"nmr","ms","ir","sds","qm","reaction","property","spectrum"}

def validate_evidence(data):
    if not isinstance(data, dict) or data.get("schema_version") != "greenroute.evidence.v1":
        raise ValueError("Expected schema_version=greenroute.evidence.v1")
    kind = data.get("kind")
    if kind not in KINDS:
        raise ValueError("Unsupported evidence kind")
    smiles = canonical_smiles(str(data.get("compound_smiles","")))
    source = str(data.get("source","")).strip()
    if not source:
        raise ValueError("Evidence source is required")
    result = dict(data, compound_smiles=smiles, source=source[:500], verified=False)
    result.pop("owner", None)
    # Imported verification flags cannot elevate evidence or alter confidence.
    if kind == "qm":
        for key in ("method","basis","units"):
            if not str(data.get(key,"")).strip():
                raise ValueError("QM evidence requires method, basis and units")
        if not isinstance(data.get("properties"), dict):
            raise ValueError("QM evidence requires a properties object")
    if kind in {"nmr","ms","ir","spectrum"}:
        origin = data.get("origin", "unknown")
        if origin not in {"experimental_reference","experimental_sample","predicted","unknown"}:
            raise ValueError("Invalid spectrum origin")
        result["origin"] = origin
        peaks = data.get("peaks",[])
        if not isinstance(peaks,list) or len(peaks) > 10000:
            raise ValueError("Invalid peak list")
        for peak in peaks:
            if not isinstance(peak,dict):
                raise ValueError("Each peak must be an object")
            for key in ("x","intensity","shift","integral"):
                if key in peak and (not isinstance(peak[key],(int,float)) or not math.isfinite(peak[key])):
                    raise ValueError("Peak numeric values must be finite")
    return result

def nmr_request(smiles, route_id=""):
    return {"schema_version":"greenroute.analysis-request.v1", "request_type":"nmr_structure_check",
            "compound_smiles":canonical_smiles(smiles), "route_id":route_id,
            "expected_response_schema":"greenroute.evidence.v1",
            "allowed_response_kinds":["nmr"],"requires_identity_confirmation":True}

def validate_manual_route(target, steps):
    from .chemistry import canonical_smiles
    target = canonical_smiles(target)
    if not isinstance(steps,list) or not 1 <= len(steps) <= 30:
        raise ValueError("Manual route must have 1–30 retro steps")
    frontier = [target]
    products = set()
    for step in steps:
        product = canonical_smiles(step["product"])
        precursors = [canonical_smiles(s) for s in step["precursors"]]
        if product not in frontier or product in products or not precursors or product in precursors:
            raise ValueError("Manual route is disconnected or cyclic")
        if any(s in products for s in precursors):
            raise ValueError("Manual route contains a cycle")
        frontier.remove(product)
        frontier.extend(precursors)
        products.add(product)
    return {"target":target, "steps":steps, "terminal_materials":frontier,
            "confidence_basis":"chemist_supplied_not_engine_validated"}

