"""Graph round-trip check for a limited subset, NOT a condition or forward-success model."""
from dataclasses import replace
from itertools import permutations
from rdkit.Chem import rdChemReactions
from .chemistry import mol_from_smiles, canonical_smiles

def graph_roundtrip(step, rule):
    if not rule.forward_smarts:
        return "not_available"
    reaction = rdChemReactions.ReactionFromSmarts(rule.forward_smarts)
    target = canonical_smiles(step.product, isomeric=False)
    for order in set(permutations(step.precursors)):
        if len(order) != reaction.GetNumReactantTemplates():
            continue
        try:
            for products in reaction.RunReactants(tuple(mol_from_smiles(s) for s in order),maxProducts=24):
                for product in products:
                    try:
                        from rdkit import Chem
                        Chem.SanitizeMol(product)
                        if canonical_smiles(product,isomeric=False) == target:
                            return "graph_roundtrip_passed_not_condition_validated"
                    except Exception:
                        pass
        except Exception:
            pass
    return "graph_roundtrip_not_matched"

def annotate_forward(route, library):
    steps = tuple(replace(step, assessment=replace(step.assessment,
                  forward_check=graph_roundtrip(step,library.by_id[step.rule_id]))) for step in route.steps)
    return replace(route,steps=steps)

