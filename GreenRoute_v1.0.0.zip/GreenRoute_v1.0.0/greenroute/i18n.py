"""New languages can be added as locales/<code>.json without changing page code."""
import json
from pathlib import Path

def languages():
    result = {"zh":{"name":"简体中文","messages":{}},"en":{"name":"English","messages":{}}}
    for path in sorted((Path(__file__).resolve().parents[1]/"locales").glob("*.json")):
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data.get("messages"),dict) and data.get("name"):
            result[path.stem] = data
    return result

def translate(zh, en, language):
    if language == "zh":
        return zh
    return languages().get(language,{}).get("messages",{}).get(en,en)
    
