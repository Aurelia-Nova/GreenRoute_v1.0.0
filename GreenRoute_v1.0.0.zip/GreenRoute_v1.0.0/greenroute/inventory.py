from __future__ import annotations

import csv
from io import StringIO
from pathlib import Path

from .chemistry import canonical_smiles, mol_from_smiles, molecule_properties
from .models import Availability, InventoryItem


ACTIVE_STATUSES = {"in_stock", "available", "catalog", "yes", "true", "1", "库存", "可采购"}


class Inventory:
    def __init__(self, items: list[InventoryItem] | None = None):
        self.items: dict[str, InventoryItem] = {}
        for item in items or []:
            self.add(item)

    @classmethod
    def from_csv_path(cls, path: str | Path, source: str = "built_in") -> "Inventory":
        with open(path, "r", encoding="utf-8-sig", newline="") as handle:
            return cls.from_csv_text(handle.read(), source=source)

    @classmethod
    def from_csv_text(cls, text: str, source: str = "uploaded") -> "Inventory":
        reader = csv.DictReader(StringIO(text))
        if not reader.fieldnames or "smiles" not in {x.strip().lower() for x in reader.fieldnames}:
            raise ValueError("库存 CSV 必须包含 smiles 列。")
        field_map = {x.strip().lower(): x for x in reader.fieldnames}
        items: list[InventoryItem] = []
        errors: list[str] = []
        for row_index, row in enumerate(reader, start=2):
            raw_smiles = (row.get(field_map["smiles"]) or "").strip()
            if not raw_smiles:
                continue
            if mol_from_smiles(raw_smiles) is None:
                errors.append(f"第 {row_index} 行 SMILES 无效")
                continue
            name = (row.get(field_map.get("name", "")) or raw_smiles).strip()
            status = (row.get(field_map.get("status", "")) or "in_stock").strip().lower()
            amount = (row.get(field_map.get("amount", "")) or "").strip()
            location = (row.get(field_map.get("location", "")) or "").strip()
            raw_cost = (row.get(field_map.get("cost_level", "")) or "2").strip()
            try:
                cost = min(5, max(1, int(raw_cost)))
            except ValueError:
                cost = 3
            items.append(
                InventoryItem(
                    smiles=canonical_smiles(raw_smiles),
                    name=name,
                    status=status,
                    cost_level=cost,
                    amount=amount,
                    location=location,
                    source=source,
                )
            )
        if errors:
            raise ValueError("；".join(errors[:5]))
        return cls(items)

    def add(self, item: InventoryItem) -> None:
        canonical = canonical_smiles(item.smiles)
        self.items[canonical] = InventoryItem(
            smiles=canonical,
            name=item.name,
            status=item.status,
            cost_level=item.cost_level,
            amount=item.amount,
            location=item.location,
            source=item.source,
        )

    def merge(self, other: "Inventory") -> "Inventory":
        merged = Inventory(list(self.items.values()))
        for item in other.items.values():
            merged.add(item)
        return merged

    def lookup(
        self,
        smiles: str,
        *,
        allow_simple_terminal: bool = True,
        simple_terminal_heavy_atoms: int = 6,
    ) -> Availability:
        canonical = canonical_smiles(smiles)
        item = self.items.get(canonical)
        if item is not None:
            available = item.status.lower() in ACTIVE_STATUSES
            return Availability(
                smiles=canonical,
                available=available,
                basis="exact_inventory" if available else "inventory_unavailable",
                name=item.name,
                cost_level=item.cost_level,
                source=item.source,
            )
        props = molecule_properties(canonical)
        if allow_simple_terminal and int(props["heavy_atoms"]) <= simple_terminal_heavy_atoms:
            return Availability(
                smiles=canonical,
                available=True,
                basis="simple_material_assumption",
                name=str(props["formula"]),
                cost_level=2,
                source="heuristic",
            )
        return Availability(
            smiles=canonical,
            available=False,
            basis="not_found",
            name=str(props["formula"]),
            cost_level=4,
            source="unknown",
        )

    def name_for(self, smiles: str) -> str:
        canonical = canonical_smiles(smiles)
        item = self.items.get(canonical)
        if item:
            return item.name
        return str(molecule_properties(canonical)["formula"])

    def as_rows(self) -> list[dict[str, str | int]]:
        return [
            {
                "name": item.name,
                "smiles": item.smiles,
                "status": item.status,
                "cost_level": item.cost_level,
                "amount": item.amount,
                "location": item.location,
                "source": item.source,
            }
            for item in sorted(self.items.values(), key=lambda x: (x.name.lower(), x.smiles))
        ]
