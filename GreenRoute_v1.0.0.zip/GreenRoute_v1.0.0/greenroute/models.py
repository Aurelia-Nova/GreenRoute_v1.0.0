from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any
import math


@dataclass(frozen=True)
class ReactionRule:
    id: str
    name_zh: str
    name_en: str
    category: str
    retrosmarts: str
    summary_zh: str
    reagents: tuple[str, ...] = ()
    solvents: tuple[str, ...] = ()
    catalysts: tuple[str, ...] = ()
    temperature: str = "ambient"
    hazard_tags: tuple[str, ...] = ()
    exposure_controls_zh: tuple[str, ...] = ()
    green_score: float = 60.0
    practicality: float = 60.0
    single_step_confidence: float = 0.60
    selectivity_risk: float = 40.0
    scale_readiness: int = 3
    evidence_level: str = "independent_rule_uncalibrated"
    enabled: bool = True
    incompatible_smarts: tuple[str, ...] = ()
    references: tuple[str, ...] = ()
    forward_smarts: str = ""
    example_product: str = ""
    caveats: tuple[str, ...] = ()

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "ReactionRule":
        tuple_fields = {
            "reagents",
            "solvents",
            "catalysts",
            "hazard_tags",
            "exposure_controls_zh",
            "incompatible_smarts", "references", "caveats",
        }
        cooked = dict(payload)
        for key in tuple_fields:
            cooked[key] = tuple(cooked.get(key, ()))
        return cls(**cooked)


@dataclass(frozen=True)
class InventoryItem:
    smiles: str
    name: str
    status: str = "in_stock"
    cost_level: int = 2
    amount: str = ""
    location: str = ""
    source: str = "built_in"


@dataclass(frozen=True)
class Availability:
    smiles: str
    available: bool
    basis: str
    name: str
    cost_level: int = 3
    source: str = "unknown"


@dataclass(frozen=True)
class StructuralAlert:
    code: str
    label_zh: str
    severity: int
    note_zh: str


@dataclass(frozen=True)
class StepAssessment:
    safety_score: float
    green_score: float
    practicality_score: float
    confidence: float
    blocked_reasons: tuple[str, ...] = ()
    cautions: tuple[str, ...] = ()
    confidence_basis: str = "rule_heuristic_uncalibrated"
    confidence_factors: tuple[str, ...] = ()
    evidence_ids: tuple[str, ...] = ()
    forward_check: str = "not_available"


@dataclass(frozen=True)
class RouteStep:
    product: str
    precursors: tuple[str, ...]
    rule_id: str
    rule_name_zh: str
    rule_category: str
    reagents: tuple[str, ...]
    solvents: tuple[str, ...]
    catalysts: tuple[str, ...]
    temperature: str
    exposure_controls_zh: tuple[str, ...]
    evidence_level: str
    assessment: StepAssessment

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class RouteResult:
    route_id: str
    target: str
    steps: tuple[RouteStep, ...]
    terminal_materials: tuple[Availability, ...]
    complete: bool
    overall_score: float
    safety_score: float
    green_score: float
    practicality_score: float
    confidence: float
    availability_score: float
    notes: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class SearchConfig:
    max_depth: int = 3
    max_routes: int = 8
    max_expansions: int = 400
    allow_simple_terminal: bool = False
    simple_terminal_heavy_atoms: int = 6
    strict_hazard_tags: frozenset[str] = field(default_factory=frozenset)
    banned_reagents: frozenset[str] = field(default_factory=frozenset)
    banned_solvents: frozenset[str] = field(default_factory=frozenset)
    enabled_categories: frozenset[str] | None = None
    excluded_smiles: frozenset[str] = field(default_factory=frozenset)
    required_intermediates: frozenset[str] = field(default_factory=frozenset)
    force_synthesis: bool = True
    step_penalty: float = 5.0
    safety_weight: float = 0.10
    green_weight: float = 0.05
    practicality_weight: float = 0.45
    confidence_weight: float = 0.25
    availability_weight: float = 0.15

    def __post_init__(self):
        if any(type(x) is not int for x in (self.max_depth,self.max_routes,self.max_expansions,self.simple_terminal_heavy_atoms)):
            raise ValueError("Search budgets must be integers")
        if not 1 <= self.max_depth <= 8 or not 1 <= self.max_routes <= 30 or not 1 <= self.max_expansions <= 3000:
            raise ValueError("Search budget exceeds supported limits")
        weights = (self.safety_weight, self.green_weight, self.practicality_weight,
                   self.confidence_weight, self.availability_weight)
        if any(not math.isfinite(w) or w < 0 for w in weights) or sum(weights) <= 0:
            raise ValueError("Invalid ranking weights")
        if not math.isfinite(self.step_penalty) or not 0 <= self.step_penalty <= 20:
            raise ValueError("Invalid step penalty")
        if not 1 <= self.simple_terminal_heavy_atoms <= 20:
            raise ValueError("Invalid simple-material size limit")


@dataclass
class SearchDiagnostics:
    expansions: int = 0
    rule_applications: int = 0
    valid_disconnections: int = 0
    blocked_disconnections: int = 0
    invalid_products: int = 0
    exhausted: bool = False

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
