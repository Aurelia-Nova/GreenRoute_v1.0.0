"""Bounded, DNS-pinned HTTP transport; no automatic redirects or ambient proxy credentials."""
from __future__ import annotations
import ipaddress
import json
import os
import socket
import ssl
from urllib.parse import urlsplit, urlencode
import urllib3

class NetworkError(ValueError):
    pass

def validate_url(url, *, allow_local=False):
    p = urlsplit(url)
    if p.scheme not in {"https", "http"} or not p.hostname or p.username or p.password or p.fragment:
        raise NetworkError("Only HTTP(S) endpoints without URL credentials/fragments are supported")
    host = p.hostname
    if len(url) > 4096 or p.port == 0:
        raise NetworkError("Invalid endpoint")
    try:
        addresses = sorted({a[4][0] for a in socket.getaddrinfo(host, p.port or (443 if p.scheme == "https" else 80), type=socket.SOCK_STREAM)})
    except OSError as exc:
        raise NetworkError("Endpoint DNS resolution failed") from exc
    trusted = {h.strip().casefold() for h in os.environ.get("GREENROUTE_TRUSTED_HOSTS", "").split(",") if h.strip()}
    approved_private = host.casefold() in trusted
    local_allowed = allow_local and os.environ.get("GREENROUTE_ALLOW_LOCAL_ENDPOINTS") == "1"
    for addr in addresses:
        ip = ipaddress.ip_address(addr.split("%")[0])
        if not ip.is_global and not (local_allowed and ip.is_loopback) and not approved_private:
            raise NetworkError("Private/loopback endpoint blocked. Administrator must explicitly allow local endpoints or trusted hosts.")
    if p.scheme != "https" and not (local_allowed or approved_private):
        raise NetworkError("HTTPS is required for remote endpoints")
    return p, addresses[0]

def request(url, *, method="GET", payload=None, headers=None, allow_local=False, max_bytes=5_000_000):
    p, ip = validate_url(url, allow_local=allow_local)
    port = p.port or (443 if p.scheme == "https" else 80)
    kwargs = dict(timeout=urllib3.Timeout(connect=5, read=35), maxsize=1, retries=False)
    if p.scheme == "https":
        pool = urllib3.HTTPSConnectionPool(ip, port, assert_hostname=p.hostname,
                                           server_hostname=p.hostname, cert_reqs=ssl.CERT_REQUIRED, **kwargs)
    else:
        pool = urllib3.HTTPConnectionPool(ip, port, **kwargs)
    request_headers = {"User-Agent":"GreenRoute/1.0 research-client", "Accept":"application/json",
                       "Host": p.netloc}
    request_headers.update(headers or {})
    body = None if payload is None else json.dumps(payload, ensure_ascii=False).encode()
    if body is not None:
        request_headers["Content-Type"] = "application/json"
    path = p.path or "/"
    if p.query:
        path += "?" + p.query
    response = None
    try:
        response = pool.request(method, path, body=body, headers=request_headers, redirect=False, preload_content=False)
        if 300 <= response.status < 400:
            raise NetworkError("Redirect refused. Configure the final endpoint explicitly.")
        if response.status >= 400:
            raise NetworkError(f"Remote service returned HTTP {response.status}")
        if response.headers.get("Content-Length") and int(response.headers["Content-Length"]) > max_bytes:
            raise NetworkError("Remote response too large")
        raw = response.read(max_bytes + 1, decode_content=True)
        if len(raw) > max_bytes:
            raise NetworkError("Remote response exceeded size limit")
        return raw
    except NetworkError:
        raise
    except Exception as exc:
        raise NetworkError("Network request failed; check endpoint, TLS certificate and connectivity") from exc
    finally:
        if response:
            response.release_conn()
        pool.close()

def json_request(url, **kwargs):
    try:
        return json.loads(request(url, **kwargs))
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise NetworkError("Remote service did not return valid JSON") from exc
