from __future__ import annotations

import html
import json
from datetime import datetime, timezone

from .chemistry import molecule_properties, molecule_svg, structural_alerts
from .inventory import Inventory
from .models import RouteResult, SearchDiagnostics
from .scoring import HAZARD_TAG_LABELS, solvent_profile


def routes_to_json(target: str, routes: list[RouteResult], diagnostics: SearchDiagnostics) -> str:
    payload = {
        "schema_version": "greenroute.route-report.v1",
        "app_version": "1.0.0",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "target": target,
        "diagnostics": diagnostics.to_dict(),
        "routes": [route.to_dict() for route in routes],
        "limitations": [
            "The independent rule library has limited reaction-space coverage.",
            "Scores are decision-support heuristics, not experimental success probabilities or SDS conclusions.",
            "All structures, conditions, compatibility, scale-up hazards and legal availability require independent verification.",
        ],
    }
    return json.dumps(payload, ensure_ascii=False, indent=2)


def routes_to_html(
    target: str,
    routes: list[RouteResult],
    diagnostics: SearchDiagnostics,
    inventory: Inventory,
) -> str:
    target_props = molecule_properties(target)
    sections = []
    for index, route in enumerate(routes, start=1):
        step_blocks = []
        for retro_index, step in enumerate(route.steps, start=1):
            precursor_cards = []
            for precursor in step.precursors:
                alerts = structural_alerts(precursor)
                alert_html = "".join(
                    f"<li><b>{html.escape(a.label_zh)}</b>（{a.severity}/5）：{html.escape(a.note_zh)}</li>"
                    for a in alerts
                ) or "<li>未命中首版结构警示；这不代表无危害。</li>"
                precursor_cards.append(
                    f"<div class='mol'><div>{molecule_svg(precursor, 260, 160)}</div>"
                    f"<code>{html.escape(precursor)}</code><ul>{alert_html}</ul></div>"
                )
            tags = "、".join(step.assessment.cautions) or "未标记"
            controls = "；".join(step.exposure_controls_zh) or "依据具体 SDS 与风险评估确定"
            step_blocks.append(
                f"""
                <section class="step">
                  <h3>逆合成步骤 {retro_index}：{html.escape(step.rule_name_zh)}</h3>
                  <p><b>产物：</b><code>{html.escape(step.product)}</code></p>
                  <div class="mols">{''.join(precursor_cards)}</div>
                  <table><tr><th>试剂</th><td>{html.escape('、'.join(step.reagents) or '按规则族选择')}</td></tr>
                  <tr><th>催化剂</th><td>{html.escape('、'.join(step.catalysts) or '无/未指定')}</td></tr>
                  <tr><th>溶剂</th><td>{html.escape('、'.join(step.solvents) or '待筛选')}</td></tr>
                  <tr><th>温区</th><td>{html.escape(step.temperature)}</td></tr>
                  <tr><th>暴露控制</th><td>{html.escape(controls)}</td></tr>
                  <tr><th>风险标签</th><td>{html.escape(tags)}</td></tr>
                  <tr><th>分项评分</th><td>安全 {step.assessment.safety_score:.0f} / 绿色 {step.assessment.green_score:.0f} / 实用 {step.assessment.practicality_score:.0f}</td></tr>
                  <tr><th>证据等级</th><td>{html.escape(step.evidence_level)}</td></tr></table>
                  <p>可信度 {step.assessment.confidence*100:.1f}%（未校准指数，非实验成功率）</p>
                </section>"""
            )
        terminals = []
        for terminal in route.terminal_materials:
            basis = {
                "exact_inventory": "库存/目录精确命中",
                "simple_material_assumption": "小分子启发式假设",
                "inventory_unavailable": "库存标记不可用",
                "not_found": "未找到",
            }.get(terminal.basis, terminal.basis)
            terminals.append(
                f"<li>{html.escape(terminal.name)} — <code>{html.escape(terminal.smiles)}</code> — {html.escape(basis)}</li>"
            )
        sections.append(
            f"""
            <article class="route">
              <h2>路线 {index} · {route.route_id} · {'已到达可得原料' if route.complete else '部分路线'}</h2>
              <div class="scores"><span>综合 {route.overall_score:.0f}</span><span>安全 {route.safety_score:.0f}</span><span>绿色 {route.green_score:.0f}</span><span>实用 {route.practicality_score:.0f}</span><span>置信 {route.confidence:.0f}</span></div>
              {''.join(step_blocks)}
              <h3>路线终点</h3><ul>{''.join(terminals)}</ul>
              <p class="note">{html.escape(' '.join(route.notes))}</p>
            </article>"""
        )
    return f"""<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><title>GreenRoute 路线报告</title>
<style>
body{{font-family:Inter,"Microsoft YaHei",Arial,sans-serif;margin:0;background:#f2f5f2;color:#18251d;line-height:1.55}}
main{{max-width:1120px;margin:0 auto;padding:32px}} h1,h2,h3{{line-height:1.25}}
.hero,.route{{background:white;border:1px solid #dbe5dc;border-radius:16px;padding:24px;margin-bottom:20px;box-shadow:0 8px 28px rgba(24,55,35,.06)}}
.scores{{display:flex;gap:10px;flex-wrap:wrap;margin:12px 0 18px}} .scores span{{background:#e8f3eb;color:#175c33;border-radius:999px;padding:6px 11px;font-weight:650}}
.step{{border-top:1px solid #e5ebe6;padding-top:14px;margin-top:18px}} .mols{{display:flex;gap:12px;flex-wrap:wrap}}
.mol{{width:280px;border:1px solid #e2e8e3;border-radius:10px;padding:8px;overflow-wrap:anywhere}} code{{font-size:12px;overflow-wrap:anywhere}}
table{{border-collapse:collapse;width:100%;margin-top:12px}} th,td{{border:1px solid #dfe6e0;padding:8px;text-align:left;vertical-align:top}} th{{width:110px;background:#f6f8f6}}
.warn{{border-left:5px solid #c47b18;background:#fff7e8;padding:12px 16px}} .note{{color:#5c6c60}}
@media print{{body{{background:white}} main{{padding:0}} .route,.hero{{box-shadow:none;break-inside:avoid}}}}
</style></head><body><main>
<section class="hero"><h1>GreenRoute v1.0 逆合成分析报告</h1>
<p><b>目标：</b><code>{html.escape(target)}</code> · {html.escape(str(target_props['formula']))} · Mr {target_props['molecular_weight']}</p>
<div>{molecule_svg(target, 420, 240)}</div>
<p>生成时间：{datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}；搜索展开 {diagnostics.expansions} 个状态，得到 {len(routes)} 条候选。</p>
<p class="warn"><b>重要：</b>本报告是路线优先级与风险初筛，不是已验证工艺、SDS、HAZOP 或放大许可。任何实验前均须核对文献、物料身份、兼容性、热风险与场地 SOP。</p></section>
{''.join(sections)}
</main></body></html>"""
