from __future__ import annotations
import json
from functools import lru_cache
from pathlib import Path

from rdkit import Chem
from rdkit.Chem import rdChemReactions

from .chemistry import canonical_smiles, mol_from_smiles
from .models import ReactionRule


class RuleLibrary:
    def __init__(self, rules: list[ReactionRule]):
        self.rules = tuple(rules)
        self.by_id = {rule.id: rule for rule in rules}
        if len(self.by_id) != len(rules):
            raise ValueError("Duplicate rule IDs")
        self._compiled: dict[str, rdChemReactions.ChemicalReaction] = {}
        errors = []
        for rule in self.rules:
            try:
                reaction = rdChemReactions.ReactionFromSmarts(rule.retrosmarts)
                if reaction is None:
                    raise ValueError("ReactionFromSmarts returned None")
                reaction.Initialize()
                self._compiled[rule.id] = reaction
            except Exception as exc:
                errors.append(f"{rule.id}: {exc}")
        if errors:
            raise ValueError("Invalid reaction rules: " + "; ".join(errors))

    @classmethod
    def from_json(cls, path: str | Path) -> "RuleLibrary":
        with open(path, "r", encoding="utf-8") as handle:
            payload = json.load(handle)
        if not isinstance(payload, list):
            raise ValueError("Reaction-rule file must contain a JSON list")
        return cls([ReactionRule.from_dict(row) for row in payload])

    @property
    def categories(self) -> tuple[str, ...]:
        return tuple(sorted({rule.category for rule in self.rules if rule.enabled}))

    def enabled_rules(self, categories: frozenset[str] | None = None) -> tuple[ReactionRule, ...]:
        return tuple(
            rule
            for rule in self.rules
            if rule.enabled and (categories is None or rule.category in categories)
        )

    def apply(self, rule: ReactionRule, target_smiles: str, max_outcomes: int = 24) -> tuple[tuple[str, ...], ...]:
        mol = mol_from_smiles(target_smiles)
        if mol is None:
            return ()
        reaction = self._compiled[rule.id]
        outcomes: set[tuple[str, ...]] = set()
        try:
            raw_outcomes = reaction.RunReactants((mol,), maxProducts=max_outcomes)
        except Exception:
            return ()
        for product_tuple in raw_outcomes:
            canonical_products = []
            valid = True
            for product in product_tuple:
                try:
                    Chem.SanitizeMol(product)
                    value = canonical_smiles(product)
                    if not value or mol_from_smiles(value) is None:
                        valid = False
                        break
                    canonical_products.append(value)
                except Exception:
                    valid = False
                    break
            if not valid:
                continue
            products = tuple(sorted(canonical_products))
            target_c = sum(a.GetAtomicNum() == 6 for a in mol.GetAtoms())
            product_c = sum(a.GetAtomicNum() == 6 for p in product_tuple for a in p.GetAtoms())
            # Ring cuts with a two-product template can duplicate the scaffold. Reject them.
            if product_c != target_c:
                continue
            if products and products != (canonical_smiles(target_smiles),):
                outcomes.add(products)
        return tuple(sorted(outcomes))

