"""Independently authored, limited-scope rules. These are not extracted SYNTHIA rules."""
from dataclasses import replace
from .models import ReactionRule
ROWS = [
("R021_SONOGASHIRA","芳基炔断开","Sonogashira coupling","C–C 构建",
 "[c:1]-[C:2]#[C:3]>>[c:1]I.[CH:2]#[C:3]","c1ccc(C#CC)cc1",.78,80,["heavy_metal"]),
("R022_HECK","芳基烯烃断开","Heck coupling","C–C 构建",
 "[c:1]-[CH:2]=[CH:3]-[#6:4]>>[c:1]Br.[CH2:2]=[CH:3]-[#6:4]","c1ccc(C=CC)cc1",.72,72,["heavy_metal"]),
("R023_IMINE","亚胺缩合断开","Imine condensation","C–N 构建",
 "[C;X3:1]=[N;X2:2]>>[C:1]=O.[N:2]","CC=NCC",.78,82,[]),
("R024_OXIME","肟缩合断开","Oxime formation","C–N 构建",
 "[C:1]=[N:2]-[OH:3]>>[C:1]=O.[N:2]-[OH:3]","CC=NO",.81,84,["energetic"]),
("R025_HYDRAZONE","腙缩合断开","Hydrazone formation","C–N 构建",
 "[C:1]=[N:2]-[N:3]>>[C:1]=O.[N:2]-[N:3]","CC=NN",.78,79,["highly_toxic"]),
("R026_ACETAL","非环缩醛断开","Acyclic acetal formation","保护基 / Protection",
 "[C;X4:1](-[O:2]-[#6:3])-[O:4]-[#6:5]>>[C:1]=O.[O:2]-[#6:3].[O:4]-[#6:5]","COC(C)OC",.77,77,["corrosive"]),
("R027_DISULFIDE","二硫键断开","Oxidative disulfide formation","C–S 构建",
 "[S;X2:1]-[S;X2:2]>>[SH:1].[SH:2]","CSSC",.79,79,["odor_exposure","strong_oxidizer"]),
("R028_SULFONE","砜回溯硫醚","Sulfide oxidation to sulfone","氧化还原",
 "[#6:1]-[S:2](=O)(=O)-[#6:3]>>[#6:1]-[S:2]-[#6:3]","CS(=O)(=O)C",.80,84,["strong_oxidizer"]),
("R029_SULFOXIDE","亚砜回溯硫醚","Sulfide oxidation to sulfoxide","氧化还原",
 "[#6:1]-[S:2](=O)-[#6:3]>>[#6:1]-[S:2]-[#6:3]","CS(=O)C",.70,74,["strong_oxidizer"]),
("R030_FC_ALKYL","芳烷基断开","Friedel–Crafts alkylation","C–C 构建",
 "[c:1]-[C;X4:2]>>[cH:1].[C:2]Cl","CC(C)(C)c1ccccc1",.60,58,["corrosive"]),
("R031_EPOXIDE","环氧化物回溯烯烃","Alkene epoxidation","氧化还原",
 "[C:1]1O[C:3]1>>[C:1]=[C:3]","CC1CO1",.75,76,["strong_oxidizer"]),
("R032_ESTER_FROM_ACYL_CHLORIDE","酯回溯酰氯与醇","Ester from acyl chloride","羧酸衍生物",
 "[C:1](=[O:2])[O:3][#6:4]>>[C:1](=[O:2])Cl.[O:3][#6:4]","CCOC(=O)c1ccccc1",.85,82,["corrosive"]),
]

EXAMPLES = {
 "R001_ESTER_ACYLATION":"CCOC(=O)c1ccccc1", "R002_AMIDE_COUPLING":"CC(=O)Nc1ccccc1",
 "R003_CARBAMATE_ISOCYANATE":"COC(=O)NC", "R004_SULFONAMIDE":"CS(=O)(=O)NC",
 "R005_WILLIAMSON_ETHER":"CCOC", "R006_ARYL_ETHER":"COc1ccccc1",
 "R007_ARYL_AMINATION":"CNc1ccccc1", "R008_SUZUKI_BIARYL":"c1ccc(-c2ccccc2)cc1",
 "R009_REDUCTIVE_AMINATION":"CCNCC", "R010_ALKYL_AMINATION":"CCNCC",
 "R011_CARBONYL_BY_OXIDATION":"CC(=O)c1ccccc1", "R012_ALCOHOL_BY_REDUCTION":"CC(O)c1ccccc1",
 "R013_ANILINE_FROM_NITRO":"Nc1ccccc1", "R014_ACID_FROM_NITRILE":"O=C(O)c1ccccc1",
 "R015_ALKENE_HYDROGENATION":"CCC", "R016_GRIGNARD_ALCOHOL":"CC(O)c1ccccc1",
 "R017_ALDOL":"CC(=O)CC(O)c1ccccc1", "R018_UREA_ISOCYANATE":"CNC(=O)NC",
 "R019_THIOETHER":"CCSC", "R020_FRIEDEL_CRAFTS_ACYLATION":"CC(=O)c1ccccc1",
}

FORWARDS = {
 "R001_ESTER_ACYLATION":"[C:1](=[O:2])O.[O:3][#6:4]>>[C:1](=[O:2])[O:3][#6:4]",
 "R002_AMIDE_COUPLING":"[C:1](=[O:2])O.[N:3]>>[C:1](=[O:2])[N:3]",
 "R008_SUZUKI_BIARYL":"[c:1]Br.[c:2]B(O)O>>[c:1]-[c:2]",
 "R012_ALCOHOL_BY_REDUCTION":"[C:1]=[O:2]>>[C:1]-[OH:2]",
 "R032_ESTER_FROM_ACYL_CHLORIDE":"[C:1](=[O:2])Cl.[O:3][#6:4]>>[C:1](=[O:2])[O:3][#6:4]",
}

def release_rules(base):
    rules = []
    for rule in base:
        changes = dict(example_product=EXAMPLES.get(rule.id,""), forward_smarts=FORWARDS.get(rule.id,""))
        if rule.id == "R002_AMIDE_COUPLING":
            changes["retrosmarts"] = "[C;!$(C(-O)=O);!$(C(-N)(-N)=O):1](=[O:2])-[N;!$(N-N=O):3]>>[C:1](=[O:2])O.[N:3]"
        if rule.id == "R005_WILLIAMSON_ETHER":
            changes["retrosmarts"] = "[C;X4;H2,H3;!R:1]-[O;X2;H0;!$(O-C=O):2]>>[C:1]Br.[O:2]"
        if rule.id == "R010_ALKYL_AMINATION":
            changes["retrosmarts"] = "[C;X4;H2,H3;!R:1]-[N;X3;!$(N-C=O):2]>>[C:1]Br.[N:2]"
        if rule.id in {"R020_FRIEDEL_CRAFTS_ACYLATION"}:
            changes["incompatible_smarts"] = ("[N+](=O)[O-]","[c]-[C]#N")
        if rule.id == "R016_GRIGNARD_ALCOHOL":
            changes["incompatible_smarts"] = ("C(=O)[OH]","[N+](=O)[O-]")
        if rule.id == "R015_ALKENE_HYDROGENATION":
            changes["enabled"] = False  # too broad for default route design; retained for audit
        rules.append(replace(rule, **changes))
    for rid,zh,en,category,smarts,example,prior,practical,tags in ROWS:
        rules.append(ReactionRule(
            id=rid,name_zh=zh,name_en=en,category=category,retrosmarts=smarts,
            summary_zh="独立编写的反应族候选；具体底物、选择性、条件及分离仍需文献和实验验证。",
            reagents=("Reaction-family reagent selection required / 需筛选反应族试剂",),
            solvents=(),temperature="Not assigned; literature verification required / 待核验",
            hazard_tags=tuple(tags), green_score=60, practicality=practical,
            single_step_confidence=prior,selectivity_risk=30,
            evidence_level="Independent rule; no substrate-specific experimental validation",
            example_product=example,forward_smarts=FORWARDS.get(rid,""),
            caveats=("Regio-/stereoselectivity and work-up are not predicted",)))
    return rules

