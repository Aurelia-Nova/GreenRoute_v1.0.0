from __future__ import annotations

import math

from .chemistry import structural_alerts, mol_from_smiles
from rdkit import Chem
from .models import Availability, ReactionRule, RouteStep, SearchConfig, StepAssessment


HAZARD_TAG_LABELS = {
    "air_sensitive": "空气/水敏感",
    "carcinogenic_concern": "致癌性关注",
    "corrosive": "腐蚀性",
    "cryogenic": "低温操作",
    "energetic": "潜在能量风险",
    "halogenated_solvent": "卤代溶剂",
    "heavy_metal": "重金属/贵金属",
    "highly_toxic": "高毒性物质",
    "odor_exposure": "强气味暴露",
    "pressurized_gas": "加压气体",
    "pyrophoric": "自燃/强反应性",
    "reproductive_toxicity": "生殖毒性关注",
    "sensitizer": "致敏性关注",
    "strong_oxidizer": "强氧化剂",
}

SOLVENT_PROFILES = {
    "water": (95, 95, "优先考虑，但需评估反应性与废水负荷。", ()),
    "ethanol": (82, 82, "易燃；整体替代属性较好。", ("water",)),
    "isopropanol": (78, 78, "易燃；可回收。", ("ethanol",)),
    "ethyl acetate": (75, 72, "易燃；通常优于卤代溶剂。", ("2-MeTHF", "ethanol")),
    "2-MeTHF": (72, 78, "易燃并可能形成过氧化物；可再生来源潜力较好。", ("ethyl acetate",)),
    "heptane": (62, 58, "易燃且有 VOC 负担。", ("ethyl acetate",)),
    "toluene": (52, 48, "易燃并有吸入/生殖毒性关注。", ("2-MeTHF", "ethyl acetate")),
    "THF": (55, 50, "易燃、易形成过氧化物。", ("2-MeTHF", "ethyl acetate")),
    "acetonitrile": (56, 55, "易燃且存在急性毒性/废物负担。", ("ethanol", "ethyl acetate")),
    "DMF": (30, 28, "生殖毒性与皮肤吸收关注。", ("ethyl acetate", "2-MeTHF")),
    "DMAc": (28, 28, "生殖毒性与皮肤吸收关注。", ("ethyl acetate", "2-MeTHF")),
    "NMP": (25, 25, "生殖毒性与皮肤吸收关注。", ("2-MeTHF", "ethyl acetate")),
    "DMSO": (68, 62, "低挥发，但可促进皮肤吸收其他物质。", ("ethanol", "water")),
    "dichloromethane": (25, 20, "高挥发卤代溶剂，存在吸入和环境负担。", ("ethyl acetate", "2-MeTHF")),
    "chloroform": (18, 15, "高挥发卤代溶剂，具有健康与环境关注。", ("ethyl acetate", "2-MeTHF")),
    "1,4-dioxane": (18, 18, "致癌性关注且易形成过氧化物。", ("2-MeTHF", "ethanol")),
    "methanol": (52, 65, "易燃并具有急性毒性。", ("ethanol",)),
}


def solvent_profile(name: str) -> tuple[float, float, str, tuple[str, ...]]:
    return SOLVENT_PROFILES.get(name.strip(), (55, 50, "尚未纳入首版溶剂指南，必须查阅 SDS。", ()))


def rule_block_reasons(rule: ReactionRule, config: SearchConfig) -> tuple[str, ...]:
    reasons = []
    tag_hits = sorted(set(rule.hazard_tags) & set(config.strict_hazard_tags))
    for tag in tag_hits:
        reasons.append(f"严格排除：{HAZARD_TAG_LABELS.get(tag, tag)}")
    for reagent in rule.reagents + rule.catalysts:
        if reagent.casefold() in {x.casefold() for x in config.banned_reagents}:
            reasons.append(f"禁用试剂/催化剂：{reagent}")
    for solvent in rule.solvents:
        if solvent.casefold() in {x.casefold() for x in config.banned_solvents}:
            reasons.append(f"禁用溶剂：{solvent}")
    return tuple(reasons)


def assess_step(rule: ReactionRule, precursors: tuple[str, ...], config: SearchConfig, product: str = "") -> StepAssessment:
    blocked = list(rule_block_reasons(rule, config))
    factors = [f"Rule prior {rule.single_step_confidence:.0%}", f"Selectivity penalty {rule.selectivity_risk / 250:.0%}"]
    if product:
        mol = mol_from_smiles(product)
        for smarts in rule.incompatible_smarts:
            query = Chem.MolFromSmarts(smarts)
            if query is None:
                raise ValueError(f"Invalid compatibility SMARTS in {rule.id}")
            if mol.HasSubstructMatch(query):
                blocked.append(f"Incompatible functional group: {smarts}")
    tag_penalty = 7.5 * len(rule.hazard_tags)
    severe_tags = {"pyrophoric", "highly_toxic", "energetic", "carcinogenic_concern"}
    tag_penalty += 7.0 * len(severe_tags & set(rule.hazard_tags))

    structural = [alert for smiles in precursors for alert in structural_alerts(smiles)]
    for alert in structural:
        mapped = {"peroxide":"energetic", "organic_azide":"energetic", "isocyanate":"highly_toxic", "organolithium":"pyrophoric"}.get(alert.code)
        if mapped and mapped in config.strict_hazard_tags:
            blocked.append(f"Precursor structural exclusion: {alert.code}")
    structural_penalty = min(30.0, sum(max(0, alert.severity - 1) * 2.0 for alert in structural))
    safety = max(0.0, 100.0 - tag_penalty - structural_penalty)

    solvent_safety = [solvent_profile(name)[0] for name in rule.solvents]
    solvent_green = [solvent_profile(name)[1] for name in rule.solvents]
    if solvent_safety:
        safety = 0.75 * safety + 0.25 * (sum(solvent_safety) / len(solvent_safety))
    green = rule.green_score
    if solvent_green:
        green = 0.70 * green + 0.30 * (sum(solvent_green) / len(solvent_green))
    if "heavy_metal" in rule.hazard_tags:
        green -= 8
    if "cryogenic" in rule.hazard_tags:
        green -= 5

    cautions = [HAZARD_TAG_LABELS.get(tag, tag) for tag in rule.hazard_tags]
    cautions.extend(alert.label_zh for alert in structural)
    cautions = list(dict.fromkeys(cautions))
    confidence = rule.single_step_confidence * (1 - rule.selectivity_risk / 250)
    if product:
        stereo = Chem.FindMolChiralCenters(mol, includeUnassigned=True)
        precursor_stereo = sum(len(Chem.FindMolChiralCenters(mol_from_smiles(s), includeUnassigned=True)) for s in precursors)
        if stereo:
            cautions.append("Stereo outcome not independently validated / 立体结果未经独立验证")
            factors.append("Stereo applicability penalty 10%")
            confidence *= 0.9
            if precursor_stereo < len(stereo):
                confidence = min(confidence, 0.55)
                factors.append("New/lost stereocenter: capped at 55%; stereocontrol requires evidence")
    confidence = max(0.05, min(0.95, confidence))
    return StepAssessment(
        safety_score=round(safety, 1),
        green_score=round(max(0.0, min(100.0, green)), 1),
        practicality_score=round(max(0.0, min(100.0, rule.practicality)), 1),
        confidence=round(confidence, 3),
        blocked_reasons=tuple(blocked),
        cautions=tuple(cautions),
        confidence_factors=tuple(factors),
    )


def aggregate_route_scores(
    steps: tuple[RouteStep, ...],
    terminals: tuple[Availability, ...],
    config: SearchConfig,
) -> dict[str, float]:
    if steps:
        safety = sum(s.assessment.safety_score for s in steps) / len(steps)
        green = sum(s.assessment.green_score for s in steps) / len(steps)
        practicality = sum(s.assessment.practicality_score for s in steps) / len(steps)
        confidence = 100.0 * math.prod(s.assessment.confidence for s in steps) ** (1 / len(steps))
    else:
        safety = green = practicality = confidence = 100.0
    availability = 100.0 * sum(t.available for t in terminals) / max(1, len(terminals))
    weighted = (
        config.safety_weight * safety
        + config.green_weight * green
        + config.practicality_weight * practicality
        + config.confidence_weight * confidence
        + config.availability_weight * availability
    )
    weighted /= (config.safety_weight + config.green_weight + config.practicality_weight + config.confidence_weight + config.availability_weight)
    weighted -= max(0, len(steps) - 1) * config.step_penalty
    return {
        "overall": round(max(0.0, min(100.0, weighted)), 1),
        "safety": round(safety, 1),
        "green": round(green, 1),
        "practicality": round(practicality, 1),
        "confidence": round(confidence, 1),
        "availability": round(availability, 1),
    }

