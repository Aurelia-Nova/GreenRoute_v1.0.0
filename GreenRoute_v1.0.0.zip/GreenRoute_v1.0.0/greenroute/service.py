from __future__ import annotations
import json
from dataclasses import asdict, replace
from functools import lru_cache
from pathlib import Path
from .rules import RuleLibrary
from .rules_extra import release_rules
from .inventory import Inventory
from .engine import RetrosynthesisEngine
from .models import SearchConfig, SearchDiagnostics

ROOT = Path(__file__).resolve().parents[1]
VERSION = "1.0.0"

@lru_cache(maxsize=1)
def rule_library():
    base = RuleLibrary.from_json(ROOT / "data/reaction_rules.json")
    return RuleLibrary(release_rules(base.rules))

def inventory_for(store, owner, *, include_demo=True):
    inventory = Inventory.from_csv_path(ROOT / "data/inventory.csv") if include_demo else Inventory()
    records = store.list(owner, "inventory", limit=1)
    if records:
        inventory = inventory.merge(Inventory.from_csv_text(records[0]["payload"]["csv"], source="user_supplied"))
    return inventory

def config_from_dict(data):
    data = dict(data or {})
    for key in ("strict_hazard_tags","banned_reagents","banned_solvents","enabled_categories",
                "excluded_smiles","required_intermediates"):
        if key in data and data[key] is not None:
            data[key] = frozenset(data[key])
    return SearchConfig(**data)

def jsonable_config(config):
    data = asdict(config)
    return {k:sorted(v) if isinstance(v,(set,frozenset)) else v for k,v in data.items()}

def make_plan(smiles, config=None, inventory=None):
    from .compounds import parse_structure
    from .forward import annotate_forward
    config = config or SearchConfig()
    inventory = inventory if inventory is not None else Inventory.from_csv_path(ROOT / "data/inventory.csv")
    library = rule_library()
    routes, diagnostics = RetrosynthesisEngine(library,inventory).search(parse_structure(smiles),config)
    routes = [annotate_forward(route,library) for route in routes]
    return {"schema_version":"greenroute.project.v1","app_version":VERSION,
            "target":parse_structure(smiles),"config":jsonable_config(config),
            "rules_version":"independent-2026-10-26","inventory_is_demo":any(i.source=="built_in" for i in inventory.items.values()),
            "routes":[r.to_dict() for r in routes],"diagnostics":diagnostics.to_dict(),
            "confidence_notice":"Uncalibrated rule-based confidence index; not experimental success probability"}

def route_csv(project):
    import csv, io
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["route_id","complete","overall","step_retro","reaction","product","precursors","confidence_percent","basis"])
    for route in project["routes"]:
        for i,step in enumerate(route["steps"],1):
            a = step["assessment"]
            writer.writerow([route["route_id"],route["complete"],route["overall_score"],i,step["rule_id"],
                             step["product"],".".join(step["precursors"]),round(a["confidence"]*100,1),a["confidence_basis"]])
    return "\ufeff"+buf.getvalue()
