"""Local SQLite store. Every record is owner-scoped; no account shares research by default."""
from __future__ import annotations
import json
import os
import sqlite3
import time
import uuid
from contextlib import contextmanager
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class Store:
    def __init__(self, path=None):
        self.path = Path(path or os.environ.get("GREENROUTE_DATA_DIR", ROOT / "var")) 
        if self.path.suffix != ".sqlite3":
            self.path = self.path / "greenroute.sqlite3"
        self.path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        with self.db() as db:
            db.executescript("""
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS users (
              id TEXT PRIMARY KEY, username TEXT UNIQUE NOT NULL, password TEXT NOT NULL,
              role TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, created REAL NOT NULL);
            CREATE TABLE IF NOT EXISTS sessions (
              hash TEXT PRIMARY KEY, owner TEXT NOT NULL, expires REAL NOT NULL,
              kind TEXT NOT NULL, scopes TEXT NOT NULL, label TEXT NOT NULL DEFAULT '');
            CREATE TABLE IF NOT EXISTS attempts (key TEXT PRIMARY KEY, count INTEGER, until REAL);
            CREATE TABLE IF NOT EXISTS records (
              owner TEXT NOT NULL, kind TEXT NOT NULL, id TEXT NOT NULL, title TEXT NOT NULL,
              payload TEXT NOT NULL, updated REAL NOT NULL,
              PRIMARY KEY(owner,kind,id));
            CREATE TABLE IF NOT EXISTS audit (
              id INTEGER PRIMARY KEY AUTOINCREMENT, owner TEXT NOT NULL, action TEXT NOT NULL,
              detail TEXT NOT NULL, timestamp REAL NOT NULL);
            PRAGMA user_version=1;
            """)
        try:
            self.path.chmod(0o600)
        except OSError:
            pass

    @contextmanager
    def db(self):
        con = sqlite3.connect(self.path, timeout=30)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA busy_timeout=30000")
        try:
            yield con
            con.commit()
        except Exception:
            con.rollback()
            raise
        finally:
            con.close()

    def audit(self, owner, action, detail=""):
        # Never pass passwords, API keys, or full chat bodies here.
        with self.db() as db:
            db.execute("INSERT INTO audit(owner,action,detail,timestamp) VALUES(?,?,?,?)",
                       (owner, action, str(detail)[:500], time.time()))

    def put(self, owner, kind, title, payload, record_id=None):
        record_id = record_id or uuid.uuid4().hex
        encoded = json.dumps(payload, ensure_ascii=False, allow_nan=False)
        if len(encoded.encode()) > 12_000_000:
            raise ValueError("Record exceeds 12 MB")
        with self.db() as db:
            db.execute("INSERT INTO records VALUES(?,?,?,?,?,?) ON CONFLICT(owner,kind,id) "
                       "DO UPDATE SET title=excluded.title,payload=excluded.payload,updated=excluded.updated",
                       (owner, kind, record_id, title[:200], encoded, time.time()))
        self.audit(owner, "save:" + kind, record_id)
        return record_id

    def list(self, owner, kind, limit=200):
        with self.db() as db:
            rows = db.execute("SELECT id,title,payload,updated FROM records WHERE owner=? AND kind=? "
                              "ORDER BY updated DESC LIMIT ?", (owner, kind, min(500, max(1, limit)))).fetchall()
        return [dict(id=r["id"], title=r["title"], payload=json.loads(r["payload"]), updated=r["updated"]) for r in rows]

    def get(self, owner, kind, record_id):
        with self.db() as db:
            row = db.execute("SELECT id,title,payload,updated FROM records WHERE owner=? AND kind=? AND id=?",
                             (owner, kind, record_id)).fetchone()
        return None if row is None else dict(id=row["id"], title=row["title"], payload=json.loads(row["payload"]), updated=row["updated"])

    def remove(self, owner, kind, record_id):
        with self.db() as db:
            db.execute("DELETE FROM records WHERE owner=? AND kind=? AND id=?", (owner, kind, record_id))
        self.audit(owner, "delete:" + kind, record_id)

    def audit_rows(self, owner):
        with self.db() as db:
            return [dict(row) for row in db.execute("SELECT action,detail,timestamp FROM audit WHERE owner=? "
                                                    "ORDER BY id DESC LIMIT 100", (owner,))]


