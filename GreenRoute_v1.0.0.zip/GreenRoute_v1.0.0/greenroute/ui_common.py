import html
import json
import streamlit as st
import plotly.graph_objects as go
from .i18n import translate
from .chemistry import molecule_png, molecule_svg

def t(zh,en):
    return translate(zh,en,st.session_state.get("language","zh"))

def json_text(data):
    return json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)

def molecule(smiles, caption=None):
    st.image(molecule_png(smiles,450,250),caption=caption,width="stretch")
    st.code(smiles,language=None)

def viewer3d(data):
    atoms,bonds = data["atoms"],data["bonds"]
    palette={"C":"#34534c","H":"#d0d7d4","N":"#467ac3","O":"#e25858","S":"#e3b742","F":"#78b764","Cl":"#5fbc70","Br":"#b46b50","I":"#9d77c4"}
    x,y,z=[],[],[]
    for i,j in bonds:
        x += [atoms[i]["x"],atoms[j]["x"],None]
        y += [atoms[i]["y"],atoms[j]["y"],None]
        z += [atoms[i]["z"],atoms[j]["z"],None]
    fig=go.Figure(go.Scatter3d(x=x,y=y,z=z,mode="lines",line=dict(color="#a8b8b1",width=5),hoverinfo="skip"))
    fig.add_trace(go.Scatter3d(x=[a["x"] for a in atoms],y=[a["y"] for a in atoms],z=[a["z"] for a in atoms],
                             mode="markers",text=[a["element"] for a in atoms],
                             marker=dict(size=[5 if a["element"]=="H" else 9 for a in atoms],
                                         color=[palette.get(a["element"],"#cd7bb9") for a in atoms]),
                             hovertemplate="%{text}<extra></extra>"))
    fig.update_layout(height=480,margin=dict(l=0,r=0,t=0,b=0),showlegend=False,
                      scene=dict(xaxis=dict(visible=False),yaxis=dict(visible=False),zaxis=dict(visible=False),aspectmode="data"))
    st.plotly_chart(fig,width="stretch")

def project_html(project):
    sections=[]
    for index,route in enumerate(project.get("routes",[]),1):
        steps=[]
        for i,step in enumerate(route["steps"],1):
            a=step["assessment"]
            precursors="".join("<div class='mol'>"+molecule_svg(s,260,170)+"<code>"+html.escape(s)+"</code></div>" for s in step["precursors"])
            steps.append(f"<section><h3>Retro {i}: {html.escape(step['rule_id'])}</h3><p>Confidence / 可信度 {a['confidence']*100:.1f}% — uncalibrated / 未校准</p>"
                         f"<p>{html.escape(step['product'])}</p><div class='row'>{precursors}</div>"
                         f"<p>Basis: {html.escape('; '.join(a.get('confidence_factors',[])))}</p>"
                         f"<p>Forward graph: {html.escape(a.get('forward_check','not_available'))}</p>"
                         f"<p>Conditions family: {html.escape(', '.join(step['reagents']))}; {html.escape(', '.join(step['solvents']))}</p>"
                         f"<p>Evidence: {html.escape(step['evidence_level'])}</p></section>")
        sections.append(f"<article><h2>Route {index} · {route['route_id']} · {'Complete (inventory basis)' if route['complete'] else 'Partial'}</h2>"
                        f"<p>Overall {route['overall_score']} · Practicality {route['practicality_score']} · Steps {len(route['steps'])}</p>"
                        +"".join(steps)+"<h3>Terminals</h3><pre>"+html.escape(json_text(route["terminal_materials"]))+"</pre></article>")
    return "<!doctype html><html><head><meta charset='utf-8'><title>GreenRoute v1.0 report</title><style>body{font-family:Arial,'Microsoft YaHei',sans-serif;max-width:1100px;margin:auto;padding:28px;color:#24352e}article{border:1px solid #d7e3dc;border-radius:12px;padding:20px;margin:20px 0}section{border-top:1px solid #d7e3dc}.row{display:flex;flex-wrap:wrap}.mol{max-width:300px;padding:12px}code,pre{white-space:pre-wrap;overflow-wrap:anywhere}.notice{padding:18px;background:#fff5d9}@media print{article{break-before:page}}</style></head><body><h1>GreenRoute v1.0.0</h1><p>"+html.escape(project["target"])+"</p>"+molecule_svg(project["target"])+"<p class='notice'>Heuristic route proposals. Confidence is not experimental success probability. Conditions are reaction families, not verified procedures. Imported reference spectra and SDS require identity/source verification. / 候选路线未经实验验证；可信度不是成功率，条件不是操作处方。</p>"+"".join(sections)+"</body></html>"

