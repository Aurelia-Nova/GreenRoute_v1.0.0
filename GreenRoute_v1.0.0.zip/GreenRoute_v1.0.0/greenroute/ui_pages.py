from __future__ import annotations
import base64
import hashlib
import io
import json
import os
from pathlib import Path
import pandas as pd
import streamlit as st
from .ui_common import t, json_text, molecule, viewer3d, project_html
from .service import rule_library, inventory_for, make_plan, config_from_dict, route_csv, ROOT
from .models import SearchConfig
from .chemistry import canonical_smiles, structural_alerts
from .compounds import (parse_structure,local_profile,generate_conformer,orca_input,resolve_pubchem,
                        pubchem_profile,pubchem_annotations,pubchem_sdf)
from .databases import BUILTINS,validate_connection,connection_url,fetch_custom
from .skills_chat import import_skill,validate_chat_config,reply,allowed_key_envs
from .evidence import validate_evidence,nmr_request,validate_manual_route
from .auth import Auth
from .scoring import HAZARD_TAG_LABELS,SOLVENT_PROFILES

EXAMPLES={
 "Acetanilide":"CC(=O)Nc1ccccc1",
 "Biphenyl":"c1ccc(-c2ccccc2)cc1",
 "Ethyl benzoate":"CCOC(=O)c1ccccc1",
 "1-Phenylethanol":"CC(O)c1ccccc1",
 "Paracetamol":"CC(=O)Nc1ccc(O)cc1",
 "Lidocaine":"CCN(CC)CC(=O)Nc1c(C)cccc1C",
}

def own_setting(store,user,name,default=None):
    row=store.get(user["id"],"settings",name)
    return row["payload"] if row else (default or {})

def decode_csv(upload):
    raw=upload.getvalue()
    if len(raw)>5_000_000:
        raise ValueError("Inventory upload exceeds 5 MB")
    for encoding in ("utf-8-sig","gb18030"):
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            pass
    raise ValueError("Save inventory as UTF-8 CSV")

def current_project():
    return st.session_state.get("project",{})

def show_route(route,index):
    library=rule_library()
    complete=t("已到达目录/库存终点","Reached catalog/inventory terminals") if route["complete"] else t("部分路线","Partial route")
    with st.container(border=True):
        st.subheader(f"{index} · {route['route_id']} · {complete}")
        columns=st.columns(5)
        for column,label,value in zip(columns,[t("综合","Overall"),t("反应步数","Steps"),t("可操作性","Practicality"),t("可信度指数","Confidence index"),t("安全初筛","Safety triage")],
                                      [route["overall_score"],len(route["steps"]),route["practicality_score"],route["confidence"],route["safety_score"]]):
            column.metric(label,value)
        st.caption(t("步骤按逆合成顺序展示；实验正向顺序相反。条件仅为反应族候选。","Steps are shown in retrosynthetic order; forward execution is reversed. Conditions are reaction-family candidates only."))
        if len(route["steps"])>1:
            with st.expander(t("查看逆合成路线网络","Inspect retrosynthesis network")):
                lines=['digraph route { rankdir=TB; node [shape=box,style=rounded];']
                def nid(smi):
                    return "m"+hashlib.sha256(smi.encode()).hexdigest()[:14]
                materials={s for step in route["steps"] for s in [step["product"]]+list(step["precursors"])}
                for smi in sorted(materials):
                    lines.append(nid(smi)+' [label='+json.dumps(smi[:80])+'];')
                for j,step in enumerate(route["steps"]):
                    label=step["rule_id"]+f" | {step['assessment']['confidence']*100:.1f}%"
                    lines.append(f'r{j} [shape=ellipse,label='+json.dumps(label)+'];')
                    lines.append(nid(step["product"])+f' -> r{j};')
                    for smi in step["precursors"]:
                        lines.append(f'r{j} -> '+nid(smi)+';')
                lines.append('}')
                st.graphviz_chart("\n".join(lines),width="stretch")
        for i,step in enumerate(route["steps"],1):
            rule=library.by_id[step["rule_id"]]
            name=rule.name_zh if st.session_state.language=="zh" else rule.name_en
            assessment=step["assessment"]
            label=f"{i}. {name} · "+t("可信度","Confidence")+f" {assessment['confidence']*100:.1f}%"
            with st.expander(label,expanded=index==1 and i==1):
                left,right=st.columns([1,1.7])
                with left:
                    molecule(step["product"],t("产物","Product"))
                with right:
                    cols=st.columns(min(3,len(step["precursors"])))
                    for col,smi in zip(cols,step["precursors"]):
                        with col:
                            molecule(smi,t("前体","Precursor"))
                st.info(t("未校准的规则可信度，不是实验成功率。","Uncalibrated rule confidence; not an experimental success probability."))
                st.write(t("评分依据","Basis")+": "+"; ".join(assessment.get("confidence_factors",[])))
                st.write(t("正向回算","Forward graph check")+": "+assessment.get("forward_check","not_available"))
                st.caption(t("结构回算通过仅说明图结构可回到目标，不说明条件、选择性或实验可行性已验证。","A graph round-trip is not experimental validation of conditions, selectivity or feasibility."))
                st.write(t("试剂族","Reagent family")+": "+"; ".join(step["reagents"]))
                st.write(t("溶剂 / 催化剂 / 温区","Solvents / catalysts / temperature")+": "
                         +", ".join(step["solvents"]+step["catalysts"])+" · "+step["temperature"])
                st.write(t("证据等级","Evidence level")+": "+step["evidence_level"])
                if assessment["cautions"]:
                    st.warning("; ".join(assessment["cautions"]))
                if step["exposure_controls_zh"]:
                    st.caption(t("暴露控制（原始规则文本）","Exposure controls (original rule text)")+": "+"; ".join(step["exposure_controls_zh"]))
        st.dataframe(pd.DataFrame(route["terminal_materials"]),hide_index=True,width="stretch")
        for note in route.get("notes",[]):
            st.caption(note)

def planning(store,user):
    st.title(t("路线规划","Route planning"))
    st.write(t("以更少步骤和更易实施的转化为优先目标，风险约束保持为硬门槛。","Prioritize fewer steps and practical transformations while retaining hard risk constraints."))
    library=rule_library()
    with st.expander(t("目标与搜索设置","Target and search settings"),expanded=True):
        left,right=st.columns([1.15,1])
        with left:
            example=st.selectbox(t("示例","Example"),list(EXAMPLES),key="target_example")
            text=st.text_area(t("SMILES、InChI 或 Molfile","SMILES, InChI or Molfile"),EXAMPLES[example],height=100,key="target_"+example)
            file=st.file_uploader(t("或导入 MOL/SDF 文件（首个结构）","Or import MOL/SDF (first record)"),type=["mol","sdf"],key="targetfile")
            if file:
                text=file.getvalue().decode("utf-8-sig")
            try:
                target=parse_structure(text)
                molecule(target)
                valid=True
            except ValueError as exc:
                st.error(str(exc));valid=False
            title=st.text_input(t("项目名称","Project name"),value=example,key="plantitle")
        with right:
            max_steps=st.slider(t("最大反应步数预算（不是最长线性序列）","Maximum total reaction-step budget (not longest linear sequence)"),1,8,4)
            max_routes=st.slider(t("候选数","Candidates"),1,20,8)
            budget=st.select_slider(t("搜索展开预算","Expansion budget"),options=[100,300,600,1200,2500],value=600)
            mode=st.selectbox(t("排序偏好","Ranking preference"),[t("简洁与可操作性","Simplicity and practicality"),t("可信度优先","Confidence first"),t("安全优先","Safety first")])
            demo=st.checkbox(t("使用演示目录（并非基地真实库存）","Use demonstration catalog (not your actual inventory)"),True,key="use_demo")
            simple=st.checkbox(t("假定未核实的小分子可采购","Assume unverified small molecules are purchasable"),False)
            categories=st.multiselect(t("反应类别（清空即禁用全部）","Reaction categories (empty disables all)"),library.categories,default=list(library.categories))
            hazard_labels={k:(v if st.session_state.language=="zh" else k) for k,v in HAZARD_TAG_LABELS.items()}
            hazards=st.multiselect(t("严格排除风险标签","Strictly excluded hazard tags"),list(HAZARD_TAG_LABELS),
                                  default=["highly_toxic","pyrophoric","energetic"],format_func=lambda k:hazard_labels[k])
            solvents=st.multiselect(t("禁用溶剂","Banned solvents"),list(SOLVENT_PROFILES),default=["DMF","NMP","1,4-dioxane","chloroform"])
            excluded=st.text_area(t("排除物料 SMILES（每行一个）","Excluded material SMILES (one per line)"),height=68)
            required=st.text_area(t("必须经过的中间体 SMILES（每行一个）","Required intermediate SMILES (one per line)"),height=68)
        if st.button(t("设计路线","Design routes"),type="primary",disabled=not valid,key="design"):
            cfg=dict(max_depth=max_steps,max_routes=max_routes,max_expansions=budget,
                     allow_simple_terminal=simple,enabled_categories=categories,
                     strict_hazard_tags=hazards,banned_solvents=solvents,
                     excluded_smiles=[s.strip() for s in excluded.splitlines() if s.strip()],
                     required_intermediates=[s.strip() for s in required.splitlines() if s.strip()])
            if mode==t("可信度优先","Confidence first"):
                cfg.update(practicality_weight=.30,confidence_weight=.40)
            elif mode==t("安全优先","Safety first"):
                cfg.update(practicality_weight=.30,safety_weight=.35,confidence_weight=.15)
            with st.spinner(t("正在搜索与评分…","Searching and scoring…")):
                project=make_plan(target,config_from_dict(cfg),inventory_for(store,user["id"],include_demo=demo))
            st.session_state.project=project
            st.session_state.project_title=title
            store.audit(user["id"],"plan_generated",f"{len(project['routes'])} candidates")
    project=current_project()
    if project:
        st.subheader(t("候选路线","Candidate routes"))
        st.code(project["target"],language=None)
        if project.get("inventory_is_demo"):
            st.warning(t("可得性包含演示目录条目，不能据此认定基地有货。","Availability includes demonstration catalog entries; do not interpret them as actual stock."))
        if not project["routes"]:
            st.warning(t("当前规则和约束下没有找到候选；这并不意味着该目标不可合成。","No route found within current rules and constraints; this does not prove the target is unsynthesizable."))
        else:
            rows=[dict(route=r["route_id"],steps=len(r["steps"]),complete=r["complete"],overall=r["overall_score"],
                       practicality=r["practicality_score"],confidence_index=r["confidence"]) for r in project["routes"]]
            st.dataframe(pd.DataFrame(rows),hide_index=True,width="stretch")
            a,b,c,d=st.columns(4)
            if a.button(t("保存项目","Save project")):
                pid=store.put(user["id"],"project",st.session_state.get("project_title","Route project"),project)
                st.session_state.project_id=pid
                st.success(t("项目已保存","Project saved"))
            b.download_button("JSON",json_text(project),"GreenRoute_project.json","application/json")
            c.download_button("HTML",project_html(project),"GreenRoute_report.html","text/html")
            d.download_button("CSV",route_csv(project).encode("utf-8"),"GreenRoute_steps.csv","text/csv")
            for index,route in enumerate(project["routes"],1):
                show_route(route,index)
        st.caption(json_text(project["diagnostics"]))
    with st.expander(t("手动单步拆分 / 多目标批量 / 人工路线","Manual one-step / multi-target batch / chemist route")):
        one_target=st.text_input(t("手动分析结构","Structure for manual expansion"),value="CC(=O)Nc1ccccc1")
        if st.button(t("枚举下一步断键","Enumerate one-step disconnections")):
            from .engine import RetrosynthesisEngine
            engine=RetrosynthesisEngine(library,inventory_for(store,user["id"]))
            st.json([step.to_dict() for step in engine.one_step(parse_structure(one_target),SearchConfig())])
        targets=st.text_area(t("批量目标，每行一个 SMILES，最多5个","Batch targets, one SMILES per line, maximum five"),height=70)
        if st.button(t("批量规划","Plan batch")):
            lines=[x.strip() for x in targets.splitlines() if x.strip()]
            if not 1<=len(lines)<=5:
                raise ValueError("Enter 1–5 targets")
            projects=[]
            for smi in lines:
                projects.append(make_plan(smi,SearchConfig(max_expansions=300),inventory_for(store,user["id"])))
            st.download_button(t("下载批量结果","Download batch results"),json_text(projects),"GreenRoute_batch.json","application/json")
            st.write({p["target"]:len(p["routes"]) for p in projects})
        manual=st.file_uploader(t("上传人工路线 JSON（含 target 和 steps）","Upload chemist route JSON (target and steps)"),type=["json"],key="manualroute")
        if manual and st.button(t("验证人工路线连接性并保存","Validate manual route connectivity and save")):
            data=json.loads(manual.getvalue())
            validated=validate_manual_route(data["target"],data["steps"])
            store.put(user["id"],"manual_route","Manual: "+validated["target"],validated)
            st.success(t("已保存；只验证连接性，不验证化学可行性。","Saved. Connectivity only—not chemical feasibility—was validated."))

def compound_page(store,user):
    st.title(t("化合物资料","Compound explorer"))
    project=current_project()
    candidates=[]
    if project:
        candidates=[project["target"]]
        candidates+=sorted({s for r in project.get("routes",[]) for step in r["steps"] for s in [step["product"]]+list(step["precursors"])} - set(candidates))
    source=st.selectbox(t("从当前路线选择或手动输入","Choose from current route or enter manually"),[t("手动输入","Manual input")]+candidates)
    smiles=st.text_input(t("结构 SMILES / InChI","Structure SMILES / InChI"),value=source if source in candidates else "CC(=O)Nc1ccccc1")
    profile=local_profile(smiles)
    key=profile["canonical_smiles"]
    left,right=st.columns([1,2])
    with left:
        molecule(key)
    with right:
        st.json(profile)
        st.caption(t("上列为本地计算描述符，不是实测熔沸点或量子化学结果。","These are local calculated descriptors, not measured melting/boiling points or quantum-chemical results."))
        st.download_button("SMILES",key,"compound.smi","text/plain")
    tabs=st.tabs([t("在线资料 / 标准图谱 / SDS","Online properties / reference spectra / SDS"),
                  t("立体结构与计算","3D & calculations"),t("本地证据与附件","Local evidence & attachments")])
    with tabs[0]:
        st.warning(t("联网会发送您输入的标识符；不会自动发送整条路线。订阅库需要用户授权。","Online retrieval sends the entered identifier, not the entire route. Subscription databases require your authorization."))
        identifier=st.text_input(t("检索名称、CAS、SMILES 或 CID","Search name, CAS, SMILES or CID"),value=key,key="compoundquery")
        idtype=st.selectbox(t("标识符类型","Identifier type"),["smiles","name","cid","inchikey"])
        consent=st.checkbox(t("同意将该检索标识符发送给 PubChem","I consent to sending this identifier to PubChem"),key="compoundconsent")
        if st.button(t("查询 PubChem 候选记录","Find PubChem candidate records"),disabled=not consent):
            st.session_state.cids=resolve_pubchem(identifier,idtype)
            st.session_state.pub_query=identifier
        cids=st.session_state.get("cids",[])
        if cids:
            st.caption(t("以下CID来自检索词：","These CIDs were returned for: ")+st.session_state.get("pub_query",""))
            cid=st.selectbox(t("确认要读取的 CID（歧义时不得混合记录）","Confirm CID (do not merge ambiguous records)"),cids)
            if st.button(t("读取该 CID 的基本属性","Retrieve properties for this CID"),disabled=not consent):
                st.session_state.pub_profile=pubchem_profile(cid)
            if st.session_state.get("pub_profile",{}).get("cid")==cid:
                st.json(st.session_state.pub_profile)
                remote_key=st.session_state.pub_profile.get("properties",{}).get("InChIKey")
                if remote_key and remote_key!=profile["inchikey"]:
                    st.warning(t("当前数据库记录与左侧结构的InChIKey不一致，不会自动合并。","This database record and the local structure have different InChIKeys; they are not automatically merged."))
            heading=st.selectbox(t("资料类别","Annotation section"),["Chemical and Physical Properties","Spectral Information","Safety and Hazards"])
            if st.button(t("读取带来源的属性 / 图谱索引 / 安全注释","Retrieve sourced properties / spectrum index / hazard annotations"),disabled=not consent):
                data=pubchem_annotations(cid,heading)
                st.session_state.pub_annotations=data
            if st.session_state.get("pub_annotations",{}).get("cid")==cid:
                data=st.session_state.pub_annotations
                st.caption(data["source"]+" · "+data["retrieved_at"])
                st.dataframe(pd.DataFrame(data["rows"]),hide_index=True,width="stretch")
                st.download_button(t("下载带来源的资料","Download sourced annotations"),json_text(data),"PubChem_annotations.json","application/json")
            if st.button(t("获取 PubChem 3D SDF（若存在）","Retrieve PubChem 3D SDF if available"),disabled=not consent):
                sdf=pubchem_sdf(cid)
                st.download_button("3D SDF",sdf,"PubChem_3D.sdf","chemical/x-mdl-sdfile")
        st.info(t("并非每种化合物都有实测标准图谱。PubChem 的谱图条目可能是外链或预测数据；必须查看原始来源、样品状态与测试条件。安全注释也不能替代具体供应商、规格与日期的 SDS。","Not every compound has measured reference spectra. PubChem spectrum annotations may be links or predictions: inspect source and acquisition conditions. Hazard annotations do not replace a supplier/product/revision-specific SDS."))
        for connection in BUILTINS:
            st.link_button(connection["name"]+" · "+connection["mode"],connection_url(connection,identifier))
    with tabs[1]:
        if st.button(t("本地生成三维构象","Generate local 3D conformer")):
            with st.spinner(t("正在生成构象…","Generating conformer…")):
                st.session_state.conformer=generate_conformer(key)
        conf=st.session_state.get("conformer")
        if conf and conf["smiles"]==key:
            viewer3d(conf)
            st.write({"force_field":conf["model"],"energy_kcal_mol":conf["energy_kcal_mol"],"converged":conf["converged"]})
            st.caption(conf["notice"])
            cols=st.columns(3)
            cols[0].download_button("3D MOL",conf["molblock"],"conformer.mol","chemical/x-mdl-molfile")
            cols[1].download_button("XYZ",conf["xyz"],"conformer.xyz","text/plain")
            cols[2].download_button("Charges JSON",json_text(conf["gasteiger_charges"]),"gasteiger_charges.json","application/json")
            charge=st.number_input(t("总电荷","Total charge"),-10,10,0)
            multiplicity=st.number_input(t("自旋多重度","Spin multiplicity"),1,9,1)
            if st.button(t("生成 ORCA 输入（不执行计算）","Generate ORCA input (does not run a calculation)")):
                inp=orca_input(conf,int(charge),int(multiplicity))
                st.download_button("ORCA .inp",inp,"compound_PBE0_def2SVP.inp","text/plain")
        st.info(t("三维构象采用 ETKDG 与可用力场，Gasteiger 电荷也是经验估计，不是晶体结构或 DFT。量子化学结果可按 QM 证据格式导入并保留方法、基组、单位和来源。","ETKDG/force-field geometry and Gasteiger charges are estimates, not crystal or DFT results. Import QM evidence with method, basis, units and provenance."))
    with tabs[2]:
        evidence_upload=st.file_uploader(t("导入 NMR / 图谱 / QM / 属性证据 JSON","Import NMR / spectrum / QM / property evidence JSON"),type=["json"],key="compoundevidence")
        if evidence_upload and st.button(t("核对身份并保存证据","Validate identity and save evidence")):
            data=validate_evidence(json.loads(evidence_upload.getvalue()))
            if data["compound_smiles"]!=key:
                raise ValueError("Evidence structure does not match the selected compound")
            store.put(user["id"],"evidence",data["kind"]+": "+key,data)
            st.success(t("已保存为未经审核的外部证据","Stored as unverified external evidence"))
        evidence=[r for r in store.list(user["id"],"evidence") if r["payload"].get("compound_smiles")==key]
        for row in evidence:
            with st.expander(row["title"]):
                st.json(row["payload"])
        st.markdown("#### "+t("上传供应商 SDS / 实测图谱文件","Attach supplier SDS / measured spectrum file"))
        attachment=st.file_uploader(t("PDF、PNG、JPG、JCAMP-DX（最多4 MB）","PDF, PNG, JPG, JCAMP-DX (max 4 MB)"),type=["pdf","png","jpg","jpeg","jdx","dx"],key="attachment")
        att_kind=st.selectbox(t("附件类型","Attachment type"),["sds","reference_spectrum","sample_spectrum"])
        att_source=st.text_input(t("供应商 / 原始文献 / 测试来源（必填）","Supplier / original reference / acquisition source (required)"))
        revision=st.text_input(t("版本日期、产品编号或测试条件","Revision date, product number or acquisition conditions"))
        if st.button(t("保存附件","Save attachment"),disabled=attachment is None):
            raw=attachment.getvalue()
            if len(raw)>4_000_000 or not att_source.strip():
                raise ValueError("Maximum 4 MB; a source is required")
            store.put(user["id"],"attachment",attachment.name,
                      {"compound_smiles":key,"kind":att_kind,"source":att_source,"revision":revision,
                       "filename":Path(attachment.name).name,"data_b64":base64.b64encode(raw).decode(),"sha256":hashlib.sha256(raw).hexdigest(),"verified":False})
            st.success(t("附件已保存；尚未审核身份与版本。","Attachment saved; identity and revision are not verified."))
        for row in store.list(user["id"],"attachment"):
            payload=row["payload"]
            if payload.get("compound_smiles")==key:
                st.download_button(row["title"]+" · "+payload["source"],base64.b64decode(payload["data_b64"]),payload["filename"],key="att_"+row["id"])

def chat_page(store,user):
    st.title(t("对话与 skills","Dialogue & skills"))
    skills=store.list(user["id"],"skill")
    skill_ids=["none"]+[r["id"] for r in skills]
    skill_labels={"none":t("无 / 基础助手","None / base assistant"),**{r["id"]:r["title"] for r in skills}}
    selected=st.selectbox(t("本账户的对话 skill","Dialogue skill for this account"),skill_ids,
                          format_func=lambda x:skill_labels[x],key="selected_skill")
    skill=next((r["payload"] for r in skills if r["id"]==selected),None)
    with st.expander(t("导入或查看 skill（只读取文本，不运行脚本）","Import or inspect skill (text only; scripts never run)")):
        upload=st.file_uploader("SKILL.md / skill.zip",type=["md","txt","zip"],key="skillupload")
        if upload and st.button(t("导入到当前账户","Import into this account")):
            data=import_skill(upload.name,upload.getvalue())
            store.put(user["id"],"skill",data["name"],data)
            st.success(t("已导入，重新选择即可使用。","Imported. Select it to use."))
            if data["ignored_files"]:
                st.write(t("已忽略非文本文件","Ignored non-text files")+": "+", ".join(data["ignored_files"]))
        if skill:
            st.text(skill["content"][:20000])
    saved=own_setting(store,user,"ai",{"mode":"offline"})
    with st.expander(t("模型 / Synthia 接口设置","Model / Synthia endpoint settings"),expanded=saved["mode"]=="offline"):
        with st.form("aiconfig"):
            adapter=st.selectbox(t("对话后端","Dialogue backend"),["offline","openai_compatible","ollama","avatar_json"],index=["offline","openai_compatible","ollama","avatar_json"].index(saved["mode"]))
            url=st.text_input(t("完整 POST 接口 URL（不会自动拼接路径）","Full POST endpoint URL (no automatic path suffix)"),value=saved.get("url",""))
            model=st.text_input(t("模型名称","Model name"),value=saved.get("model",""))
            env=st.text_input(t("API密钥的环境变量名称（不填写密钥本身）","API key environment variable name (not the key itself)"),value=saved.get("api_key_env",""))
            local=st.checkbox(t("允许管理员已授权的本地接口","Allow administrator-approved local endpoint"),saved.get("allow_local",False))
            submitted=st.form_submit_button(t("保存接口","Save endpoint"))
        st.caption(t("本账户密钥变量必须使用前缀：","Key variables for this account must use prefix: ")+"GREENROUTE_KEY_"+user["id"][:12].upper()+"_")
        if submitted:
            config=validate_chat_config(dict(mode=adapter,url=url,model=model,api_key_env=env,allow_local=local))
            prefix="GREENROUTE_KEY_"+user["id"][:12].upper()+"_"
            if config.get("api_key_env") and not config["api_key_env"].startswith(prefix):
                raise ValueError("API key variable is not assigned to this account")
            store.put(user["id"],"settings","AI endpoint",config,record_id="ai")
            saved=config
            st.success(t("接口已保存；未发送测试请求。","Endpoint saved; no test request was sent."))
    st.caption(t("离线助手只汇总已生成路线；开放式自然语言化学讨论需要配置语言模型或 Synthia。","The offline assistant only summarizes existing routes. Open-ended chemistry dialogue requires a configured language model or Synthia endpoint."))
    send_context=st.checkbox(t("附带当前路线上下文","Include current route context"),False)
    consent=st.checkbox(t("同意将本条对话、选定 skill 和勾选的上下文发送给所配置的接口","I consent to sending this message, selected skill and checked context to the configured endpoint"),False)
    context=current_project() if send_context else {}
    if st.session_state.get("chat_skill")!=selected:
        st.session_state.chat_history=[]
        st.session_state.chat_skill=selected
    history=st.session_state.setdefault("chat_history",[])
    for message in history:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])
    prompt=st.chat_input(t("讨论路线、可信度或化学问题","Discuss routes, confidence or chemistry"))
    if prompt:
        with st.spinner(t("正在生成答复…","Generating response…")):
            answer=reply(prompt,st.session_state.language,context,config=saved,skill=skill,
                         history=history,consent=consent,user_id=user["id"])
        history.extend([{"role":"user","content":prompt},{"role":"assistant","content":answer}])
        st.session_state.chat_history=history[-40:]
        st.rerun()
    a,b=st.columns(2)
    if a.button(t("清空本次对话","Clear this conversation")):
        st.session_state.chat_history=[];st.rerun()
    if b.button(t("保存本次对话到本账户","Save conversation to this account")):
        store.put(user["id"],"chat","Dialogue",{"skill_id":selected,"messages":history})
        st.success(t("对话已保存","Conversation saved"))

def projects_page(store,user):
    st.title(t("项目与反馈","Projects & feedback"))
    rows=store.list(user["id"],"project")
    if not rows:
        st.info(t("暂无保存项目。请先规划并保存。","No saved project. Plan and save one first."))
    else:
        chosen=st.selectbox(t("项目","Project"),[r["id"] for r in rows],format_func=lambda x:next(r["title"] for r in rows if r["id"]==x))
        row=store.get(user["id"],"project",chosen)
        a,b=st.columns(2)
        if a.button(t("加载到路线与对话工作区","Load into route and dialogue workspace")):
            st.session_state.project=row["payload"];st.session_state.project_id=chosen;st.session_state.project_title=row["title"]
            st.success(t("已加载，请切换至路线规划或对话。","Loaded. Open route planning or dialogue."))
        b.download_button(t("导出项目","Export project"),json_text(row["payload"]),"GreenRoute_project.json","application/json")
        route=st.selectbox(t("反馈路线 ID","Route for feedback"),[r["route_id"] for r in row["payload"]["routes"]])
        decision=st.selectbox(t("化学家判断","Chemist decision"),["accept","reject","modify"])
        reason=st.selectbox(t("原因类别","Reason"),["feasible","selectivity","stereochemistry","availability","workup","purification","safety","cost","evidence_missing","other"])
        note=st.text_area(t("具体理由 / 实验结果","Reason / experimental observations"))
        if st.button(t("保存反馈（不会自动改动可信度）","Save feedback (does not automatically change confidence)")):
            store.put(user["id"],"feedback",route,dict(project_id=chosen,route_id=route,decision=decision,reason=reason,note=note))
            st.success(t("反馈已保存","Feedback saved"))
    with st.expander(t("查看已保存反馈与人工路线","Saved feedback and manual routes")):
        for kind in ("feedback","manual_route"):
            for row in store.list(user["id"],kind):
                st.json(row)

def database_page(store,user):
    st.title(t("数据库连接","Database connections"))
    st.info(t("公开 API、网站跳转和自建 REST 是不同能力。Reaxys、CAS SciFinder 等不含免费数据访问或已实现的商业 API。","Public APIs, browser links and custom REST are distinct. Reaxys/CAS links do not include data subscriptions or implemented commercial APIs."))
    st.dataframe(pd.DataFrame(BUILTINS),hide_index=True,width="stretch")
    with st.form("dbform"):
        name=st.text_input(t("自定义数据库名称","Custom database name"))
        mode=st.selectbox(t("连接方式","Connection mode"),["web_link","json_rest"])
        url=st.text_input(t("URL模板（检索参数用 {query}）","URL template (use {query} for search)"))
        env=st.text_input(t("密钥环境变量名（可选）","API key environment variable (optional)"))
        local=st.checkbox(t("本地 / 内网服务（需管理员授权）","Local / intranet service (requires administrator approval)"))
        submit=st.form_submit_button(t("添加数据库","Add database"))
    if submit:
        conn=validate_connection(dict(name=name,mode=mode,url=url,api_key_env=env,allow_local=local))
        if env and not env.startswith("GREENROUTE_KEY_"+user["id"][:12].upper()+"_"):
            raise ValueError("API key variable is not assigned to this account")
        store.put(user["id"],"connection",name,conn)
        st.success(t("已添加","Added"))
    query=st.text_input(t("测试检索词（发送前先确认）","Test query (review before sending)"),"aspirin")
    for row in store.list(user["id"],"connection"):
        conn=row["payload"]
        with st.container(border=True):
            st.write(row["title"]+" · "+conn["mode"])
            if conn["mode"]=="web_link":
                st.link_button(t("打开数据库检索入口","Open database search"),connection_url(conn,query))
            else:
                approved=st.checkbox(t("同意向此数据库发送检索词","Consent to sending the query to this database"),key="dbc_"+row["id"])
                if st.button(t("执行检索","Run query"),key="dbq_"+row["id"],disabled=not approved):
                    st.json(fetch_custom(conn,query,key_env_allowed=allowed_key_envs(user["id"])))
            if st.checkbox(t("确认移除此连接","Confirm removal of this connection"),key="dbrc_"+row["id"]):
                if st.button(t("移除连接","Remove connection"),key="dbr_"+row["id"]):
                    store.remove(user["id"],"connection",row["id"]);st.rerun()

def integration_page(store,user):
    st.title(t("软件互联","Software integration"))
    st.write(t("通过版本化 JSON 和带权限令牌的本地 REST API 关联核磁解谱软件、数据库与互联网替身。现有核磁软件或 Synthia 需实现相同协议或安装适配层；本版不声称已直接兼容其当前内部接口。","Versioned JSON and scoped local REST connect NMR software, databases and an avatar. Existing software must implement the contract or an adapter; its current private interfaces are not claimed to be directly compatible."))
    st.code("python api_server.py\nhttp://127.0.0.1:8502/docs",language="text")
    with st.form("newtoken"):
        label=st.text_input(t("接入方名称","Client label"),"NMR / Synthia")
        scopes=st.multiselect(t("令牌权限","Token scopes"),["read","plan","evidence","chat"],default=["read","evidence"])
        days=st.slider(t("有效期（天）","Expiry (days)"),1,90,30)
        create=st.form_submit_button(t("创建令牌（仅显示一次）","Create token (shown once)"))
    if create:
        if not scopes:
            raise ValueError("Select at least one scope")
        token=Auth(store).issue(user["id"],ttl=days*86400,scopes=scopes,label=label)
        st.warning(t("请立即复制；不会再显示。令牌可访问本账户授权数据。","Copy now; it will not be displayed again. This token grants scoped access to this account."))
        st.code(token,language=None)
    for token in Auth(store).tokens(user["id"]):
        st.write({"label":token["label"],"scopes":token["scopes"],"expires":token["expires"]})
        if st.button(t("撤销令牌","Revoke token"),key="revoke_"+token["hash"]):
            Auth(store).revoke(user["id"],token["hash"]);st.rerun()
    smiles=st.text_input(t("要交给核磁软件的候选结构","Candidate structure for NMR software"),current_project().get("target","CCO"))
    st.download_button(t("导出核磁分析请求 JSON","Export NMR analysis request JSON"),json_text(nmr_request(smiles)),"GreenRoute_NMR_request.json","application/json")
    upload=st.file_uploader(t("导入其它软件返回的证据 JSON","Import evidence JSON returned by another application"),type=["json"],key="bridgefile")
    if upload and st.button(t("验证协议并保存","Validate contract and save")):
        data=validate_evidence(json.loads(upload.getvalue()))
        store.put(user["id"],"evidence",data["kind"]+": "+data["compound_smiles"],data)
        st.success(t("导入完成；原始 verified 标记不会被信任。","Imported. An external verified flag is not trusted."))
    st.markdown("#### "+t("接口与示例","Contracts and examples"))
    for name in ["nmr_evidence.json","qm_evidence.json","avatar_response.json","manual_route.json"]:
        path=ROOT/"examples"/name
        if path.exists():
            st.download_button(name,path.read_bytes(),name,"application/json",key="ex_"+name)

def inventory_page(store,user):
    st.title(t("库存","Inventory"))
    st.warning(t("内置目录只用于演示。真实库存或可采购性需要由基地审核；小分子并不自动等于可购。","The built-in catalog is a demo. Actual stock and purchasability require your verification; small does not mean available."))
    upload=st.file_uploader(t("上传库存CSV","Upload inventory CSV"),type=["csv"],key="invfile")
    if upload and st.button(t("校验并保存本账户库存","Validate and save this account's inventory")):
        from .inventory import Inventory
        text=decode_csv(upload)
        inv=Inventory.from_csv_text(text,source="user_supplied")
        store.put(user["id"],"inventory","User inventory",{"csv":text},record_id="inventory")
        st.success(t("已保存条目：","Saved entries: ")+str(len(inv.items)))
    st.download_button(t("下载库存模板","Download inventory template"),(ROOT/"data/inventory_template.csv").read_bytes(),"inventory_template.csv","text/csv")
    demo=st.checkbox(t("预览中包含演示目录","Include demonstration catalog in preview"),True)
    st.dataframe(pd.DataFrame(inventory_for(store,user["id"],include_demo=demo).as_rows()),hide_index=True,width="stretch")

def rule_page(store,user):
    st.title(t("规则审计","Rule audit"))
    library=rule_library()
    st.write(t("规则总数 / 默认启用数","Total rules / enabled by default")+f": {len(library.rules)} / {sum(r.enabled for r in library.rules)}")
    st.info(t("规则是独立编写的通用知识，不含 SYNTHIA 代码或专有规则库。未进行前瞻性湿实验验证；不能据此声称达到 SYNTHIA 水平。","Rules are independently authored general chemistry, not SYNTHIA code or proprietary rule data. No prospective wet-lab validation; parity with SYNTHIA is not claimed."))
    rows=[dict(id=r.id,name=r.name_zh if st.session_state.language=="zh" else r.name_en,category=r.category,
               enabled=r.enabled,prior_percent=r.single_step_confidence*100,practicality=r.practicality,
               evidence=r.evidence_level,has_forward_graph_check=bool(r.forward_smarts)) for r in library.rules]
    st.dataframe(pd.DataFrame(rows),hide_index=True,width="stretch")
    chosen=st.selectbox(t("查看规则","Inspect rule"),[r.id for r in library.rules])
    from dataclasses import asdict
    st.json(asdict(library.by_id[chosen]))
    st.caption(t("基线可信度与校正系数是启发式先验；只有积累冻结测试集和前瞻实验后才能进行统计校准。","Confidence baselines and corrections are heuristic priors. Statistical calibration requires held-out and prospective experiments."))

def account_page(store,user):
    st.title(t("账户与安全","Account & security"))
    st.write({"username":user["username"],"role":user["role"],"session_expires":user["expires"]})
    st.caption(t("口令采用带随机盐的 PBKDF2-SHA256（600,000轮）；会话8小时过期；登录失败限速。项目和 skills 按账号隔离，API令牌可撤销。数据库不提供静态加密，跨主机部署需 TLS、磁盘加密、反向代理和独立安全审计。","Passwords use salted PBKDF2-SHA256 (600,000 iterations); sessions expire in 8 hours; failed logins are throttled. Projects and skills are owner-scoped and API tokens revocable. The database is not encrypted at rest; multi-host use requires TLS, disk encryption, a reverse proxy and security review."))
    with st.form("changepass"):
        old=st.text_input(t("当前密码","Current password"),type="password")
        new=st.text_input(t("新密码","New password"),type="password")
        confirm=st.text_input(t("再次输入新密码","Confirm new password"),type="password")
        submit=st.form_submit_button(t("修改密码并撤销全部会话","Change password and revoke all sessions"))
    if submit:
        if new!=confirm:
            raise ValueError("Passwords do not match")
        Auth(store).change_password(user["id"],old,new)
        st.session_state.clear();st.rerun()
    if user["role"]=="admin":
        with st.expander(t("管理员创建其它账户","Administrator: create another account")):
            with st.form("createchemist"):
                username=st.text_input(t("新用户名","New username"))
                password=st.text_input(t("新账户密码","New account password"),type="password")
                create=st.form_submit_button(t("创建化学家账户","Create chemist account"))
            if create:
                Auth(store).create_user(username,password,actor=user["id"])
                st.success(t("账户已创建，请安全交付初始口令。","Account created; deliver the initial password securely."))
    st.dataframe(pd.DataFrame(store.audit_rows(user["id"])),hide_index=True,width="stretch")
