@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Start the main application once to install dependencies.
  pause
  exit /b 1
)
echo GreenRoute API: http://127.0.0.1:8502/docs
".venv\Scripts\python.exe" api_server.py
endlocal
