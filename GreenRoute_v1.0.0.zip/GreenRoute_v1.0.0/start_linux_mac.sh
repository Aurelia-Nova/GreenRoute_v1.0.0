#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
if [ ! -x .venv/bin/python ]; then
  python3 -m venv .venv
fi
if ! .venv/bin/python -c "import rdkit,streamlit,fastapi,uvicorn,urllib3,plotly,pandas; assert rdkit.__version__ == '2026.03.6'; assert streamlit.__version__ == '1.63.0'" 2>/dev/null; then
  .venv/bin/python -m ensurepip --upgrade
  .venv/bin/python -m pip install --disable-pip-version-check -r requirements.txt
fi
exec .venv/bin/python -m streamlit run app.py --server.address localhost --server.port 8501 --browser.gatherUsageStats false

