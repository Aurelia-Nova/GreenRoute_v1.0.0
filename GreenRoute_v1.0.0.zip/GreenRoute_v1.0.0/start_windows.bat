@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
  echo [GreenRoute] Creating an isolated environment...
  py -3.14 -m venv .venv 2>nul
  if errorlevel 1 py -3 -m venv .venv
  if errorlevel 1 python -m venv .venv
  if errorlevel 1 (
    echo [GreenRoute] Could not create the environment.
    pause
    exit /b 1
  )
)

echo [GreenRoute] Checking dependencies...
".venv\Scripts\python.exe" -c "import sys; assert sys.version_info >= (3,11); import rdkit,streamlit,fastapi,uvicorn,urllib3,plotly,pandas; assert rdkit.__version__ == '2026.03.6'; assert streamlit.__version__ == '1.63.0'" >nul 2>nul
if not errorlevel 1 goto run_app
".venv\Scripts\python.exe" -m ensurepip --upgrade
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r requirements.txt
if errorlevel 1 (
  echo [GreenRoute] Dependency installation failed. Check the network/proxy and retry.
  pause
  exit /b 1
)

:run_app
echo [GreenRoute v1.0] Starting at http://localhost:8501 ...
".venv\Scripts\python.exe" -m streamlit run app.py --server.address localhost --server.port 8501 --browser.gatherUsageStats false
endlocal

