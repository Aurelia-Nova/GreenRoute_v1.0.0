import pytest
from greenroute.storage import Store
from greenroute.auth import Auth

@pytest.fixture
def account(tmp_path):
    store=Store(tmp_path/"test.sqlite3")
    auth=Auth(store)
    uid=auth.create_user("chemist","correct horse battery staple",bootstrap=True)
    return store,auth,uid