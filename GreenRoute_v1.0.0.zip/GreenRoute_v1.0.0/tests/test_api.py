from fastapi.testclient import TestClient
from greenroute.api import create_app


def test_auth_scopes_and_planning(account):
    store,auth,uid=account
    client=TestClient(create_app(store))
    assert client.get("/health").status_code==200
    assert client.get("/api/v1/projects").status_code==401
    read=auth.issue(uid,scopes=["read"])
    headers={"Authorization":"Bearer "+read}
    assert client.get("/api/v1/capabilities",headers=headers).status_code==200
    assert client.post("/api/v1/routes",headers=headers,json={"target":"CCO"}).status_code==403
    plan=auth.issue(uid,scopes=["read","plan"])
    headers={"Authorization":"Bearer "+plan}
    response=client.post("/api/v1/routes",headers=headers,json={"target":"CC(=O)Nc1ccccc1","save":True})
    assert response.status_code==200
    assert response.json()["routes"] and response.json()["project_id"]
    assert client.get("/api/v1/projects",headers=headers).json()

def test_api_does_not_expose_other_accounts(account):
    store,auth,uid=account
    other=auth.create_user("other","another passphrase",actor=uid)
    rid=store.put(uid,"project","Private",{"target":"CCO","routes":[]})
    token=auth.issue(other,scopes=["read"])
    client=TestClient(create_app(store))
    response=client.get("/api/v1/projects/"+rid,headers={"Authorization":"Bearer "+token})
    assert response.status_code==404

def test_login_evidence_chat_and_compound_endpoints(account):
    store,auth,uid=account
    client=TestClient(create_app(store))
    response=client.post("/api/v1/auth/login",json={"username":"chemist","password":"correct horse battery staple"})
    assert response.status_code==200
    headers={"Authorization":"Bearer "+response.json()["access_token"]}
    assert client.get("/api/v1/compounds/local",params={"smiles":"CCO"},headers=headers).json()["formula"]=="C2H6O"
    body={"schema_version":"greenroute.evidence.v1","kind":"nmr","compound_smiles":"CCO","source":"test","origin":"experimental_sample","peaks":[]}
    assert client.post("/api/v1/evidence",json=body,headers=headers).status_code==200
    assert len(client.get("/api/v1/evidence",headers=headers).json())==1
    assert client.get("/api/v1/nmr/request",params={"smiles":"CCO"},headers=headers).status_code==200
    assert client.get("/api/v1/compounds/pubchem",params={"query":"ethanol"},headers=headers).status_code==422
    assert client.post("/api/v1/chat",headers=headers,json={"message":"Summarize","language":"en"}).status_code==200

def test_input_limits_and_security_headers(account):
    store,auth,uid=account
    client=TestClient(create_app(store))
    headers={"Authorization":"Bearer "+auth.issue(uid,scopes=["plan"])}
    assert client.post("/api/v1/routes",headers=headers,json={"target":"CCO","config":{"max_expansions":100000}}).status_code==422
    assert client.get("/health").headers["X-Content-Type-Options"]=="nosniff"
