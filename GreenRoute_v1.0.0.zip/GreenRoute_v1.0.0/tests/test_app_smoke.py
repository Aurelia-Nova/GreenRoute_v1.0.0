from pathlib import Path
import pytest
from streamlit.testing.v1 import AppTest
from greenroute.storage import Store
from greenroute.auth import Auth

ROOT=Path(__file__).resolve().parents[1]


@pytest.fixture
def signed_app(tmp_path,monkeypatch):
    monkeypatch.setenv("GREENROUTE_DATA_DIR",str(tmp_path/"uidata"))
    store=Store()
    auth=Auth(store)
    auth.create_user("chemist","correct horse battery staple",bootstrap=True)
    app=AppTest.from_file(str(ROOT/"app.py"),default_timeout=30)
    app.session_state["session_token"]=auth.login("chemist","correct horse battery staple")
    app.session_state["language"]="zh"
    app.run()
    assert not app.exception
    return app

def test_login_page_without_users(tmp_path,monkeypatch):
    monkeypatch.setenv("GREENROUTE_DATA_DIR",str(tmp_path/"new"))
    app=AppTest.from_file(str(ROOT/"app.py"),default_timeout=30).run()
    assert not app.exception
    assert any("创建管理员" in b.label for b in app.button)

def test_signed_in_route_plan_and_local_compound(signed_app):
    app=signed_app
    next(b for b in app.button if b.label=="设计路线").click().run(timeout=30)
    assert not app.exception
    assert any("可信度" in exp.label and "%" in exp.label for exp in app.expander)
    app.radio(key="page").set_value("compounds").run()
    assert not app.exception

@pytest.mark.parametrize("page",["chat","projects","databases","integrations","inventory","rules","account"])
def test_pages_load_without_exception(signed_app,page):
    app=signed_app
    app.radio(key="page").set_value(page).run()
    assert not app.exception

def test_english_ui_and_signout(signed_app):
    app=signed_app
    app.selectbox(key="language").set_value("en").run()
    assert not app.exception
    assert any(b.label=="Design routes" for b in app.button)
    next(b for b in app.button if b.label=="Sign out").click().run()
    assert not app.exception
    assert any("Sign in" in b.label for b in app.button)
