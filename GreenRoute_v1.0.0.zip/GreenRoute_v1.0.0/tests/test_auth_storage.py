import time
import pytest
from greenroute.auth import Auth,hash_password,verify_password,token_hash

def test_password_hash_is_salted_and_validated():
    a=hash_password("long enough passphrase")
    b=hash_password("long enough passphrase")
    assert a!=b and verify_password("long enough passphrase",a)
    assert not verify_password("wrong",a)
    assert "long enough passphrase" not in a

def test_password_length_enforced():
    with pytest.raises(ValueError):
        hash_password("short")

def test_no_second_bootstrap_or_unauthorized_registration(account):
    store,auth,uid=account
    with pytest.raises(ValueError):
        auth.create_user("attacker","another passphrase",bootstrap=True)
    with pytest.raises(PermissionError):
        auth.create_user("attacker","another passphrase")
    other=auth.create_user("other","another passphrase",actor=uid)
    with pytest.raises(PermissionError):
        auth.create_user("third","another passphrase",actor=other)

def test_rate_limit_and_generic_failure(account):
    _,auth,_=account
    for _ in range(5):
        with pytest.raises(ValueError,match="Invalid"):
            auth.login("missing","wrong")
    with pytest.raises(ValueError,match="Too many"):
        auth.login("missing","wrong")

def test_token_scopes_hash_expiry_and_revocation(account):
    store,auth,uid=account
    token=auth.issue(uid,scopes=["read"])
    assert auth.validate(token,scope="read")
    assert auth.validate(token,scope="plan") is None
    with store.db() as db:
        stored=db.execute("SELECT hash FROM sessions").fetchone()[0]
    assert stored==token_hash(token) and token not in stored
    auth.revoke(uid,stored)
    assert auth.validate(token) is None
    expired=auth.issue(uid,ttl=-1)
    assert auth.validate(expired) is None

def test_password_change_revokes_all_tokens(account):
    _,auth,uid=account
    token=auth.login("chemist","correct horse battery staple")
    auth.change_password(uid,"correct horse battery staple","a newly changed passphrase")
    assert auth.validate(token) is None
    assert auth.login("chemist","a newly changed passphrase")

def test_owner_isolation_with_known_ids(account):
    store,auth,uid=account
    other=auth.create_user("other","another passphrase",actor=uid)
    rid=store.put(uid,"skill","Private",{"content":"secret"})
    assert store.get(other,"skill",rid) is None
    store.remove(other,"skill",rid)
    assert store.get(uid,"skill",rid)
    assert store.list(other,"skill")==[]
