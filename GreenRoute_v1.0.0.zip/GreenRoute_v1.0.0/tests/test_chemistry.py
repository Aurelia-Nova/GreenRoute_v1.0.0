from greenroute.chemistry import canonical_smiles, mol_from_smiles, molecule_properties, structural_alerts


def test_smiles_validation_and_properties():
    assert canonical_smiles("C(C)O") == "CCO"
    assert mol_from_smiles("C1CC") is None
    props = molecule_properties("CCO")
    assert props["formula"] == "C2H6O"
    assert props["heavy_atoms"] == 3


def test_structural_alerts_find_peroxide_and_isocyanate():
    peroxide_codes = {alert.code for alert in structural_alerts("CCOOCC")}
    isocyanate_codes = {alert.code for alert in structural_alerts("CCN=C=O")}
    assert "peroxide" in peroxide_codes
    assert "isocyanate" in isocyanate_codes


def test_no_alert_is_not_an_error():
    assert structural_alerts("CCO") == ()
