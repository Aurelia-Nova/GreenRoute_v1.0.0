import pytest
from greenroute.compounds import parse_structure,local_profile,generate_conformer,orca_input,_flatten_sections
from greenroute.evidence import validate_evidence,validate_manual_route,nmr_request

def test_structure_and_local_identifiers():
    p=local_profile("CCO")
    assert p["formula"]=="C2H6O" and p["inchikey"]
    assert parse_structure(p["inchi"])=="CCO"

def test_conformer_roundtrip_and_qm_input():
    data=generate_conformer("C[C@H](O)C(=O)O")
    assert data["atoms"] and data["molblock"] and data["xyz"]
    assert "@@" in parse_structure(data["molblock"]) or "@" in parse_structure(data["molblock"])
    inp=orca_input(data,0,1)
    assert "* xyz 0 1" in inp and "PBE0" in inp
    with pytest.raises(ValueError):
        orca_input(data,0,2)

def test_annotation_provenance_preserved():
    sections=[{"TOCHeading":"Melting Point","Information":[{"ReferenceNumber":1,"Value":{"StringWithMarkup":[{"String":"100 deg C"}]}}]}]
    rows=_flatten_sections(sections,{1:{"SourceName":"Example lab","URL":"https://example.org/data"}})
    assert rows[0]["value"]=="100 deg C"
    assert rows[0]["source_name"]=="Example lab" and rows[0]["source_url"]

def test_import_does_not_trust_external_verified_flag():
    data=validate_evidence({"schema_version":"greenroute.evidence.v1","kind":"nmr","compound_smiles":"CCO","source":"NMR","verified":True,"origin":"predicted","peaks":[]})
    assert data["verified"] is False and data["origin"]=="predicted"

def test_qm_metadata_required():
    with pytest.raises(ValueError):
        validate_evidence({"schema_version":"greenroute.evidence.v1","kind":"qm","compound_smiles":"CCO","source":"x"})

def test_bad_peaks_and_protocol_rejected():
    with pytest.raises(ValueError):
        validate_evidence({"schema_version":"bad","kind":"nmr"})
    with pytest.raises(ValueError):
        validate_evidence({"schema_version":"greenroute.evidence.v1","kind":"nmr","compound_smiles":"CCO","source":"x","peaks":[{"shift":float("nan")}]})

def test_manual_route_connectivity():
    route=validate_manual_route("CC(=O)Nc1ccccc1",[{"product":"CC(=O)Nc1ccccc1","precursors":["CC(=O)O","Nc1ccccc1"]}])
    assert route["terminal_materials"]
    with pytest.raises(ValueError):
        validate_manual_route("CCO",[{"product":"CC","precursors":["C"]}])
    assert nmr_request("CCO")["expected_response_schema"]=="greenroute.evidence.v1"
