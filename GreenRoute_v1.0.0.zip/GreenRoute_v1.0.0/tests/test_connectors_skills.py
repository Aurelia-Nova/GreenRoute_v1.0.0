import io
import json
import zipfile
import pytest
from greenroute.skills_chat import import_skill,reply,validate_chat_config
from greenroute.databases import validate_connection,connection_url
from greenroute.network import validate_url,NetworkError

def test_text_skill_and_ignored_script():
    buf=io.BytesIO()
    with zipfile.ZipFile(buf,"w") as z:
        z.writestr("reviewer/SKILL.md","---\nname: reviewer\n---\nReason carefully")
        z.writestr("reviewer/scripts/run.py","raise RuntimeError('must never run')")
    data=import_skill("skill.zip",buf.getvalue())
    assert data["name"]=="reviewer" and data["ignored_files"]
    assert data["execution"]=="text_only_no_tools"

def test_skill_zip_slip_rejected():
    buf=io.BytesIO()
    with zipfile.ZipFile(buf,"w") as z:
        z.writestr("../SKILL.md","bad")
    with pytest.raises(ValueError):
        import_skill("bad.zip",buf.getvalue())

def test_custom_url_escaping_and_secret_rejection():
    c=validate_connection(dict(name="Internal",mode="json_rest",url="https://example.org/search?q={query}"))
    assert "C%2FC%3DC%5CCl" in connection_url(c,"C/C=C\\Cl")
    with pytest.raises(ValueError):
        validate_connection(dict(name="Bad",url="https://user:secret@example.org"))
    with pytest.raises(ValueError):
        validate_connection(dict(name="Bad",url="https://example.org",api_key_env="sk_secret"))

@pytest.mark.parametrize("url",["http://169.254.169.254/","http://127.0.0.1:22/","https://10.0.0.1/","file:///etc/passwd","https://user:pass@example.org"])
def test_ssrf_and_url_credential_blocking(url,monkeypatch):
    monkeypatch.delenv("GREENROUTE_TRUSTED_HOSTS",raising=False)
    monkeypatch.delenv("GREENROUTE_ALLOW_LOCAL_ENDPOINTS",raising=False)
    with pytest.raises(NetworkError):
        validate_url(url)

def test_cloud_chat_requires_consent():
    config={"mode":"openai_compatible","url":"https://example.org/chat","model":"test"}
    with pytest.raises(PermissionError):
        reply("Question","en",{},config=config,consent=False)

def test_chat_adapter_contracts_are_operational(monkeypatch):
    seen=[]
    def mocked(url,**kw):
        seen.append(kw["payload"])
        return {"choices":[{"message":{"content":"Structured answer"}}]}
    monkeypatch.setattr("greenroute.skills_chat.json_request",mocked)
    response=reply("Question","en",{"routes":[]},config={"mode":"openai_compatible","url":"https://example.org/chat","model":"test"},
                   skill={"name":"reviewer","content":"Be precise"},consent=True)
    assert response=="Structured answer"
    assert seen[0]["messages"][-1]["content"]=="Question"

def test_avatar_adapter(monkeypatch):
    monkeypatch.setattr("greenroute.skills_chat.json_request",lambda *a,**kw:{"reply":"Avatar response"})
    assert reply("hello","en",{},config={"mode":"avatar_json","url":"https://example.org/avatar"},consent=True)=="Avatar response"

def test_offline_mode_honestly_reports_its_limits():
    answer=reply("hello","en",{},config={"mode":"offline"})
    assert "no language model" in answer

