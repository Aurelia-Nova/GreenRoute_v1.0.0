from pathlib import Path

import pytest

from greenroute.engine import RetrosynthesisEngine
from greenroute.inventory import Inventory
from greenroute.models import SearchConfig
from greenroute.rules import RuleLibrary


ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture(scope="module")
def assets():
    rules = RuleLibrary.from_json(ROOT / "data" / "reaction_rules.json")
    inventory = Inventory.from_csv_path(ROOT / "data" / "inventory.csv")
    return rules, inventory


def base_config(rules, **overrides):
    values = dict(
        max_depth=3,
        max_routes=8,
        max_expansions=400,
        strict_hazard_tags=frozenset({"highly_toxic", "pyrophoric", "energetic", "carcinogenic_concern"}),
        banned_solvents=frozenset({"dmf", "nmp", "1,4-dioxane", "chloroform"}),
        enabled_categories=frozenset(rules.categories),
    )
    values.update(overrides)
    return SearchConfig(**values)


@pytest.mark.parametrize(
    "target,expected_rule",
    [
        ("c1ccc(-c2ccccc2)cc1", "R008_SUZUKI_BIARYL"),
        ("CC(=O)Nc1ccccc1", "R002_AMIDE_COUPLING"),
        ("CCOC(=O)c1ccccc1", "R001_ESTER_ACYLATION"),
        ("CC(O)c1ccccc1", "R012_ALCOHOL_BY_REDUCTION"),
    ],
)
def test_representative_targets_reach_inventory(assets, target, expected_rule):
    rules, inventory = assets
    results, diagnostics = RetrosynthesisEngine(rules, inventory).search(target, base_config(rules))
    assert diagnostics.valid_disconnections > 0
    assert any(route.complete for route in results)
    assert any(expected_rule in {step.rule_id for step in route.steps} for route in results if route.complete)


def test_strict_heavy_metal_filter_blocks_suzuki(assets):
    rules, inventory = assets
    config = base_config(rules, strict_hazard_tags=frozenset({"heavy_metal"}))
    results, diagnostics = RetrosynthesisEngine(rules, inventory).search(
        "c1ccc(-c2ccccc2)cc1", config
    )
    assert not results
    assert diagnostics.blocked_disconnections > 0


def test_route_scores_are_bounded_and_partial_route_is_labelled(assets):
    rules, inventory = assets
    results, _ = RetrosynthesisEngine(rules, inventory).search(
        "CC(=O)Nc1ccc(O)cc1", base_config(rules, max_depth=2)
    )
    assert results
    assert any(not route.complete for route in results)
    for route in results:
        for score in (
            route.overall_score,
            route.safety_score,
            route.green_score,
            route.practicality_score,
            route.confidence,
            route.availability_score,
        ):
            assert 0 <= score <= 100


def test_search_does_not_repeat_decomposed_target(assets):
    rules, inventory = assets
    results, _ = RetrosynthesisEngine(rules, inventory).search(
        "CCNCC", base_config(rules, max_depth=5, max_expansions=800)
    )
    for route in results:
        products = [step.product for step in route.steps]
        assert len(products) == len(set(products))

