import json
import threading
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
import pytest
from greenroute.network import request,json_request,NetworkError
from greenroute.skills_chat import reply

class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args):
        pass
    def do_GET(self):
        if self.path=="/redirect":
            self.send_response(302);self.send_header("Location","http://169.254.169.254/");self.end_headers()
        else:
            raw=json.dumps({"ok":True}).encode()
            self.send_response(200);self.send_header("Content-Length",str(len(raw)));self.end_headers();self.wfile.write(raw)
    def do_POST(self):
        data=json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        assert data.get("messages")
        raw=json.dumps({"reply":"Avatar HTTP contract confirmed"}).encode()
        self.send_response(200);self.send_header("Content-Length",str(len(raw)));self.end_headers();self.wfile.write(raw)

@pytest.fixture
def local_server(monkeypatch):
    monkeypatch.setenv("GREENROUTE_ALLOW_LOCAL_ENDPOINTS","1")
    server=ThreadingHTTPServer(("127.0.0.1",0),Handler)
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    yield f"http://127.0.0.1:{server.server_port}"
    server.shutdown();server.server_close();thread.join(timeout=2)

def test_dns_pinned_transport_real_local_http(local_server):
    assert json_request(local_server,allow_local=True)=={"ok":True}
    with pytest.raises(NetworkError,match="Redirect"):
        request(local_server+"/redirect",allow_local=True)
    with pytest.raises(NetworkError,match="large|limit"):
        request(local_server,allow_local=True,max_bytes=2)

def test_avatar_works_over_http_contract(local_server):
    assert reply("Test","en",{},config={"mode":"avatar_json","url":local_server,"allow_local":True},
                 consent=True)=="Avatar HTTP contract confirmed"

