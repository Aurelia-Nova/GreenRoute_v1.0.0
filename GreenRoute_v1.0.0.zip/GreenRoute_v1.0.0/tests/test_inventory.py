from pathlib import Path

from greenroute.inventory import Inventory


ROOT = Path(__file__).resolve().parents[1]


def test_builtin_inventory_exact_and_simple_lookup():
    inventory = Inventory.from_csv_path(ROOT / "data" / "inventory.csv")
    exact = inventory.lookup("c1ccccc1Br")
    simple = inventory.lookup("CC=O")
    missing = inventory.lookup("CCCCCCCCCCCC")
    assert exact.available and exact.basis == "exact_inventory"
    assert simple.available and simple.basis == "simple_material_assumption"
    assert not missing.available and missing.basis == "not_found"


def test_uploaded_inventory_overrides_builtin_entry():
    builtin = Inventory.from_csv_path(ROOT / "data" / "inventory.csv")
    uploaded = Inventory.from_csv_text(
        "name,smiles,status,cost_level,amount,location\n"
        "实验室溴苯,c1ccccc1Br,unavailable,5,0,B-02\n"
    )
    merged = builtin.merge(uploaded)
    hit = merged.lookup("Brc1ccccc1")
    assert not hit.available
    assert hit.name == "实验室溴苯"
    assert hit.cost_level == 5


def test_inventory_requires_smiles_column():
    try:
        Inventory.from_csv_text("name,status\nfoo,in_stock\n")
    except ValueError as exc:
        assert "smiles" in str(exc)
    else:
        raise AssertionError("missing smiles column was accepted")

