import pytest
from rdkit import Chem
from greenroute.service import rule_library,make_plan
from greenroute.models import SearchConfig
from greenroute.scoring import assess_step

def test_all_32_independent_rules_have_valid_examples():
    library=rule_library()
    assert len(library.rules)==32
    assert sum(r.enabled for r in library.rules)==31
    for rule in library.rules:
        outcomes=library.apply(rule,rule.example_product)
        assert outcomes,rule.id
        n=sum(a.GetAtomicNum()==6 for a in Chem.MolFromSmiles(rule.example_product).GetAtoms())
        for outcome in outcomes:
            assert sum(a.GetAtomicNum()==6 for s in outcome for a in Chem.MolFromSmiles(s).GetAtoms())==n

def test_empty_categories_really_disable_all():
    p=make_plan("CC(=O)Nc1ccccc1",SearchConfig(enabled_categories=frozenset()))
    assert not p["routes"]

def test_confidence_and_graph_check_per_step():
    p=make_plan("CC(=O)Nc1ccccc1")
    step=p["routes"][0]["steps"][0]
    assert .0<step["assessment"]["confidence"]<1
    assert step["assessment"]["confidence_basis"]=="rule_heuristic_uncalibrated"
    assert "passed" in step["assessment"]["forward_check"]

def test_root_in_inventory_is_still_expanded():
    p=make_plan("CC(=O)c1ccccc1")
    assert p["routes"] and all(r["steps"] for r in p["routes"])

def test_stereo_confidence_capped():
    rule=rule_library().by_id["R012_ALCOHOL_BY_REDUCTION"]
    a=assess_step(rule,("CC(=O)c1ccccc1",),SearchConfig(),"C[C@H](O)c1ccccc1")
    assert a.confidence<=.55
    assert any("Stereo" in factor for factor in a.confidence_factors)

def test_cyclic_amide_does_not_duplicate_scaffold():
    library=rule_library()
    assert library.apply(library.by_id["R002_AMIDE_COUPLING"],"O=C1NCCC1")==()

def test_repeated_precursor_stoichiometry_is_retained():
    library=rule_library()
    outcomes=library.apply(library.by_id["R027_DISULFIDE"],"CSSC")
    assert outcomes==(("CS","CS"),)

def test_substrate_compatibility_hard_filter():
    rule=rule_library().by_id["R020_FRIEDEL_CRAFTS_ACYLATION"]
    a=assess_step(rule,("CC(=O)Cl","O=[N+]([O-])c1ccccc1"),SearchConfig(),"CC(=O)c1ccc([N+](=O)[O-])cc1")
    assert a.blocked_reasons

def test_required_and_excluded_materials():
    p=make_plan("CCOC(=O)c1ccccc1",SearchConfig(excluded_smiles=frozenset({"CCO"})))
    assert not p["routes"]
    p=make_plan("CC(=O)Nc1ccccc1",SearchConfig(required_intermediates=frozenset({"CCCCCCCCCC"})))
    assert not p["routes"]

def test_search_limits_validate():
    with pytest.raises(ValueError):
        SearchConfig(max_expansions=100000)
    with pytest.raises(ValueError):
        SearchConfig(confidence_weight=float("nan"))
    with pytest.raises(ValueError):
        SearchConfig(max_depth=2.5)
