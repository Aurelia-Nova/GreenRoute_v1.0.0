import json
from pathlib import Path

from greenroute.engine import RetrosynthesisEngine
from greenroute.inventory import Inventory
from greenroute.models import SearchConfig
from greenroute.report import routes_to_html, routes_to_json
from greenroute.rules import RuleLibrary


ROOT = Path(__file__).resolve().parents[1]


def test_report_exports_are_self_describing():
    rules = RuleLibrary.from_json(ROOT / "data" / "reaction_rules.json")
    inventory = Inventory.from_csv_path(ROOT / "data" / "inventory.csv")
    config = SearchConfig(enabled_categories=frozenset(rules.categories))
    routes, diagnostics = RetrosynthesisEngine(rules, inventory).search(
        "CC(=O)Nc1ccccc1", config
    )
    json_text = routes_to_json("CC(=O)Nc1ccccc1", routes, diagnostics)
    payload = json.loads(json_text)
    assert payload["schema_version"] == "greenroute.route-report.v1"
    assert payload["routes"]
    html_text = routes_to_html("CC(=O)Nc1ccccc1", routes, diagnostics, inventory)
    assert "GreenRoute v1.0" in html_text
    assert "重要" in html_text
    assert routes[0].route_id in html_text
