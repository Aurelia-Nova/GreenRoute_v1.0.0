from pathlib import Path

from greenroute.rules import RuleLibrary

ROOT = Path(__file__).resolve().parents[1]


def load_rules():
    return RuleLibrary.from_json(ROOT / "data" / "reaction_rules.json")


def test_all_rules_compile_and_ids_are_unique():
    rules = load_rules()
    assert len(rules.rules) == 20
    assert len(rules.by_id) == len(rules.rules)


def test_key_disconnections_generate_expected_precursors():
    rules = load_rules()
    cases = {
        "R001_ESTER_ACYLATION": ("CCOC(=O)c1ccccc1", {"CCO", "O=C(O)c1ccccc1"}),
        "R002_AMIDE_COUPLING": ("CC(=O)Nc1ccccc1", {"CC(=O)O", "Nc1ccccc1"}),
        "R008_SUZUKI_BIARYL": ("c1ccc(-c2ccccc2)cc1", {"Brc1ccccc1", "OB(O)c1ccccc1"}),
        "R012_ALCOHOL_BY_REDUCTION": ("CC(O)c1ccccc1", {"CC(=O)c1ccccc1"}),
        "R013_ANILINE_FROM_NITRO": ("Nc1ccccc1", {"O=[N+]([O-])c1ccccc1"}),
        "R020_FRIEDEL_CRAFTS_ACYLATION": ("CC(=O)c1ccccc1", {"CC(=O)Cl", "c1ccccc1"}),
    }
    for rule_id, (target, expected) in cases.items():
        outcomes = rules.apply(rules.by_id[rule_id], target)
        assert any(set(outcome) == expected for outcome in outcomes), (rule_id, outcomes)


def test_rule_application_deduplicates_symmetric_biaryl_sites():
    rules = load_rules()
    outcomes = rules.apply(rules.by_id["R008_SUZUKI_BIARYL"], "c1ccc(-c2ccccc2)cc1")
    assert len(outcomes) == 1

